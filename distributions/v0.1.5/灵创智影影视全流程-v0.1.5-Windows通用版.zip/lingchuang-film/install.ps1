﻿[CmdletBinding()]
param(
    [ValidateSet('Codex', 'WorkBuddy')][string]$App,
    [ValidateSet('Codex', 'WorkBuddy')][string]$CallerApp,
    [string]$UserRoot = $env:USERPROFILE,
    [string]$PythonExecutable = 'python',
    [switch]$SkipDependencies
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ($CallerApp) {
    if ($App -and $App -ne $CallerApp) { throw '当前宿主与目标平台不一致，未执行安装。' }
    $App = $CallerApp
}
if (-not $App) {
    $choice = Read-Host '无法从此终端确定宿主。仅选择一个安装平台：1 = Codex，2 = WorkBuddy'
    if ($choice -eq '1') { $App = 'Codex' }
    elseif ($choice -eq '2') { $App = 'WorkBuddy' }
    else { throw '未选择有效平台，未执行安装。' }
}
Write-Output "本次仅安装到：$App。不会自动继续安装另一平台。"
if (-not [IO.Path]::IsPathRooted($UserRoot)) { throw 'UserRoot 必须为绝对路径。' }
$homeRoot = [IO.Path]::GetFullPath($UserRoot).TrimEnd('\', '/')
if (-not (Test-Path -LiteralPath $homeRoot -PathType Container)) { throw '用户目录不存在。' }
$source = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'skills\lingchuang-film'))
$hostFolder = if ($App -eq 'Codex') { '.agents' } else { '.workbuddy' }
$scanRoot = Join-Path $homeRoot "$hostFolder\skills"
$target = Join-Path $scanRoot 'lingchuang-film'
$legacy = Join-Path $scanRoot 'lingchuang-video'
$backupRoot = Join-Path $homeRoot '.lingchuang-skill-backups'

function Assert-OwnedPath([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path)
    if (-not $full.StartsWith($homeRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
        throw "路径越出指定用户目录：$full"
    }
    $cursor = $full
    while ($cursor -and $cursor.Length -ge $homeRoot.Length) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "路径包含链接，停止自动移动：$cursor" }
        }
        $cursor = Split-Path -Parent $cursor
    }
}
function Assert-PlainTree([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { throw "不是文件夹：$Path" }
    $children = @(Get-ChildItem -LiteralPath $Path -Force)
    foreach ($child in $children) {
        if (($child.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "目录内含链接，停止处理：$($child.FullName)" }
        if ($child.PSIsContainer) {
            if ($child.Name -in @('.film', '.lczyai', 'outputs', '.git')) { throw "目录中发现项目记录，停止自动升级：$($child.FullName)" }
            Assert-PlainTree $child.FullName
        }
    }
}
function Assert-Skill([string]$Path, [string]$Name) {
    Assert-PlainTree $Path
    $entry = Join-Path $Path 'SKILL.md'
    if (-not (Test-Path -LiteralPath $entry -PathType Leaf)) { throw "没有技能入口，未移动：$Path" }
    $text = Get-Content -LiteralPath $entry -Raw -Encoding UTF8
    if ($text -notmatch ('(?m)^name:\s*' + [regex]::Escape($Name) + '\s*$')) { throw "技能身份不匹配，未移动：$Path" }
}
function Tree-Hashes([string]$Path) {
    $result = @{}
    foreach ($file in Get-ChildItem -LiteralPath $Path -File -Recurse -Force) {
        $key = $file.FullName.Substring($Path.Length).TrimStart('\', '/')
        $result[$key] = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
    }
    return $result
}
Assert-PlainTree $source
$entries = @(Get-ChildItem -LiteralPath $source -Filter SKILL.md -Recurse -File)
if ($entries.Count -ne 1 -or $entries[0].FullName -ne (Join-Path $source 'SKILL.md')) { throw '包内必须只有总入口 SKILL.md。' }
foreach ($p in @($scanRoot, $target, $legacy, $backupRoot)) { Assert-OwnedPath $p }
if ($source.StartsWith($scanRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw '请从技能扫描目录之外的解压包运行安装。' }
if (Test-Path -LiteralPath $target) { Assert-Skill $target 'lingchuang-film' }
if (Test-Path -LiteralPath $legacy) { Assert-Skill $legacy 'lingchuang-video' }
if (-not $SkipDependencies) { $null = Get-Command $PythonExecutable -ErrorAction Stop }
$backup = Join-Path $backupRoot ($App + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8))
Assert-OwnedPath $backup
$null = New-Item -ItemType Directory -Path $backup -Force
$null = New-Item -ItemType Directory -Path $scanRoot -Force
$moved = [Collections.Generic.List[object]]::new()
$created = $false
try {
    foreach ($old in @($target, $legacy)) {
        if (-not (Test-Path -LiteralPath $old)) { continue }
        $saved = Join-Path $backup (Split-Path -Leaf $old)
        # Verify both final absolute paths before each recursive directory move.
        Assert-OwnedPath $old
        Assert-OwnedPath $saved
        $before = Tree-Hashes $old
        Move-Item -LiteralPath $old -Destination $saved
        $moved.Add(@{source=$old; backup=$saved})
        $after = Tree-Hashes $saved
        if ($before.Count -ne $after.Count) { throw '备份文件数量不符。' }
        foreach ($key in $before.Keys) { if ($before[$key] -ne $after[$key]) { throw "备份校验失败：$key" } }
    }
    $null = New-Item -ItemType Directory -Path $target
    $created = $true
    Get-ChildItem -LiteralPath $source -Force | Copy-Item -Destination $target -Recurse
    $expected = Tree-Hashes $source
    $actual = Tree-Hashes $target
    if ($expected.Count -ne $actual.Count) { throw '安装文件数量不符。' }
    foreach ($key in $expected.Keys) { if ($expected[$key] -ne $actual[$key]) { throw "安装文件校验失败：$key" } }
    if (-not $SkipDependencies) {
        & $PythonExecutable -m venv (Join-Path $target '.venv')
        if ($LASTEXITCODE -ne 0) { throw '创建独立 Python 环境失败。' }
        $venvPython = Join-Path $target '.venv\Scripts\python.exe'
        & $venvPython -m pip install -r (Join-Path $target 'requirements.txt')
        if ($LASTEXITCODE -ne 0) { throw '依赖安装失败。' }
        & $venvPython (Join-Path $target 'scripts\doctor.py')
        if ($LASTEXITCODE -ne 0) { throw '环境自检未通过。' }
    }
    $record = @{version='0.1.5'; app=$App; callerApp=$CallerApp; target=$target; backup=$backup; archived=@($moved.ToArray()); dependenciesChecked=(-not $SkipDependencies); installedAt=(Get-Date -Format o)}
    $record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $backup 'installation.json') -Encoding UTF8
    $record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $target 'installation.json') -Encoding UTF8
    if ($SkipDependencies) { Write-Output '文件安装测试完成；已跳过依赖，不能据此认定可生产。' }
    else { Write-Output "安装完成：$App / v0.1.5" }
    Write-Output "技能位置：$target"
    Write-Output "旧版与日志：$backup"
    Write-Output '重新打开所选软件，只选择 lingchuang-film。未删除项目、未提交生成；未处理其他软件或项目级技能目录。'
} catch {
    $failure = $_
    if ($created -and (Test-Path -LiteralPath $target)) {
        $failed = Join-Path $backup 'failed-new-install'
        Assert-OwnedPath $target
        Assert-OwnedPath $failed
        Move-Item -LiteralPath $target -Destination $failed
    }
    for ($i=$moved.Count-1; $i -ge 0; $i--) {
        $entry = $moved[$i]
        Assert-OwnedPath $entry.backup
        Assert-OwnedPath $entry.source
        Move-Item -LiteralPath $entry.backup -Destination $entry.source
    }
    "安装失败；已恢复已移动的旧版。失败现场保留于 $backup。原因：$($failure.Exception.Message)" | Set-Content -LiteralPath (Join-Path $backup 'failure.txt') -Encoding UTF8
    throw $failure
}
