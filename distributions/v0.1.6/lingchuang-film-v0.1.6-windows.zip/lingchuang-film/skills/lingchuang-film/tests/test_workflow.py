import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import film
import deliver

class MockClient:
    def __init__(self):
        self.submissions=[];self.fail=False;self.quote_calls=0
        self.result={'run_id':'run-1','status':'running','settled_points':None,'settlement_status':'pending','items':[{'task_id':'t1','estimated_points':2,'actual_points_cost':None,'settlement_status':'pending'}],'canvas':{'project_id':'same-canvas'}}
    def models(self):return {'models':[{'id':'image-model','kind':'image','stage':'image'},{'id':'video-model','kind':'video','stage':'generate'},{'id':'depth-model','kind':'video','stage':'video_depth'}]}
    def quote(self,m):self.quote_calls+=1;return {'quote_id':'q1','estimated_points':2,'items':[{'estimated_points':2}]}
    def submit(self,q,c):
        self.submissions.append(q)
        if self.fail:raise OSError('simulated lost response')
        return {'run_id':'run-1','status':'queued'}
    def requote(self,q):return {'quote_id':'q2','estimated_points':3}
    def status(self,r):return copy.deepcopy(self.result)
    def download(self,r):return {'files':[]}

class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        self.state=film.init(self.root,'commercial','sample');self.client=MockClient();self.factory=lambda *_:self.client
        self.spec={'project_name':'sample','script_revision':'v1','scenes':[{'scene_id':'SC01','model':'image-model','prompt':'approved'}]}
        film.write(self.root/'plan.json',self.spec)
        film.plan(self.root,self.state,'images','image','production','plan.json')
    def planned(self):
        film.approve_plan(self.root,self.state,'images',self.state['stages']['images']['fingerprint'],'user approved')
    def quoted(self):
        self.planned();return film.quote_stage(self.root,self.state,'images',self.factory)
    def approved(self):
        q=self.quoted();film.approve_cost(self.root,self.state,'images',q['id'],q['approval_points'],'user approved fee')
    def test_quote_requires_plan_approval(self):
        with self.assertRaises(ValueError):film.quote_stage(self.root,self.state,'images',self.factory)
        self.assertEqual(self.client.quote_calls,0)
    def test_submit_requires_cost_approval(self):
        self.quoted()
        with self.assertRaises(ValueError):film.submit(self.root,self.state,'images',factory=self.factory)
        self.assertEqual(self.client.submissions,[])
    def test_wrong_quote_or_amount_rejected(self):
        self.quoted()
        for q,n in [('other',2),('q1',1)]:
            with self.assertRaises(ValueError):film.approve_cost(self.root,self.state,'images',q,n,'yes')
    def test_changed_plan_invalidates_approval(self):
        self.approved();self.spec['scenes'][0]['prompt']='changed';film.write(self.root/'plan.json',self.spec)
        with self.assertRaises(ValueError):film.submit(self.root,self.state,'images',factory=self.factory)
    def test_changed_reference_bytes_invalidates_plan(self):
        (self.root/'image.png').write_bytes(b'v1');self.spec['scenes'][0]['images']=['image.png'];film.write(self.root/'plan2.json',self.spec)
        row=film.plan(self.root,self.state,'refs','image','production','plan2.json');(self.root/'image.png').write_bytes(b'v2')
        with self.assertRaises(ValueError):film.approve_plan(self.root,self.state,'refs',row['fingerprint'],'yes')
    def test_mixed_media_phase_rejected(self):
        self.spec['scenes'].append({'scene_id':'SC02','model':'video-model','prompt':'x'});film.write(self.root/'mixed.json',self.spec)
        row=film.plan(self.root,self.state,'mixed','image','production','mixed.json');film.approve_plan(self.root,self.state,'mixed',row['fingerprint'],'yes')
        with self.assertRaises(ValueError):film.quote_stage(self.root,self.state,'mixed',self.factory)
    def test_repeated_submit_does_not_resubmit(self):
        self.approved();film.submit(self.root,self.state,'images',factory=self.factory);film.submit(self.root,self.state,'images',factory=self.factory)
        self.assertEqual(self.client.submissions,['q1'])
    def test_lost_response_recovers_same_quote(self):
        self.approved();self.client.fail=True
        with self.assertRaises(OSError):film.submit(self.root,self.state,'images',factory=self.factory)
        restored=film.read(self.root/'.film/project.json');self.assertEqual(restored['stages']['images']['status'],'unknown')
        with self.assertRaises(ValueError):film.refresh(self.root,restored,'images',self.factory)
        with self.assertRaises(ValueError):film.submit(self.root,restored,'images',factory=self.factory)
        self.client.fail=False;film.submit(self.root,restored,'images',True,self.factory)
        self.assertEqual(self.client.submissions,['q1','q1'])
        self.assertEqual(restored['stages']['images']['remote_id'],'run-1')
    def test_refresh_requires_new_confirmation(self):
        self.approved();film.refresh(self.root,self.state,'images',self.factory)
        self.assertFalse(self.state['stages']['images']['cost_approved'])
        self.assertEqual(self.state['stages']['images']['history'][0]['id'],'q1')
    def test_pending_actual_cost_not_zero_and_sync_no_generation(self):
        self.approved();film.submit(self.root,self.state,'images',factory=self.factory)
        row=film.sync(self.root,self.state,'images',True,self.factory)
        self.assertIsNone(row['actual_points']);self.assertIsNone(row['items'][0]['actual_points_cost'])
        self.assertEqual(row['result']['canvas']['project_id'],'same-canvas');self.assertEqual(self.client.submissions,['q1'])
        self.client.result.update(settled_points=1.8,settlement_status='settled')
        self.assertEqual(film.sync(self.root,self.state,'images',factory=self.factory)['actual_points'],1.8)
    def test_depth_model_verified_before_quote(self):
        spec={'scenes':[{'scene_id':'REF','model':'depth-model','reviewed':True,'videos_asset_ids':['owned-id']}],'project_name':'sample','script_revision':'v1'}
        film.write(self.root/'depth.json',spec);row=film.plan(self.root,self.state,'depth','depth','production','depth.json')
        film.approve_plan(self.root,self.state,'depth',row['fingerprint'],'yes');film.quote_stage(self.root,self.state,'depth',self.factory)
        self.assertEqual(self.client.quote_calls,1)
    def test_latest_version_not_implicitly_selected(self):
        for i in (1,2):
            (self.root/f'{i}.mp4').write_bytes(str(i).encode());film.add_asset(self.root,self.state,f'a{i}','SC01',f'v{i}',f'{i}.mp4','video')
        film.review_asset(self.root,self.state,'a1','approved','yes');film.select_asset(self.root,self.state,'a1')
        with self.assertRaises(ValueError):film.select_asset(self.root,self.state,'a2')
        self.assertEqual(self.state['selected']['SC01'],'a1')
    def test_derived_asset_keeps_parent_and_stage(self):
        (self.root/'a.mp4').write_bytes(b'x');film.add_asset(self.root,self.state,'original','REF','v1','a.mp4','video')
        a=film.add_asset(self.root,self.state,'white','WHITE','v2','a.mp4','depth','original','images')
        self.assertEqual(a['parent'],'original');self.assertEqual(a['stage'],'images')
    def test_path_escape_rejected(self):
        with self.assertRaises(ValueError):film.local(self.root,'../outside.mp4')
    def test_project_lock_excludes_second_writer(self):
        with film.locked(self.root):
            with self.assertRaises(ValueError):
                with film.locked(self.root):pass
    def test_duck_only_during_dialogue(self):
        self.assertEqual(deliver.duck_parts(0,8,[(2,4)],0.4,0.25),[(0,2,0.4),(2,4,0.1),(4,8,0.4)])
    def test_trim_cannot_cut_dialogue(self):
        (self.root/'a.mp4').write_bytes(b'x');film.add_asset(self.root,self.state,'a','SC01','v1','a.mp4','video');film.review_asset(self.root,self.state,'a','approved','yes');film.select_asset(self.root,self.state,'a');film.write(self.root/'.film/project.json',self.state)
        with patch.object(deliver,'media',return_value={'video':True,'audio':True,'duration':8}):
            with self.assertRaises(ValueError):deliver.validate(self.root,{'shots':[{'scene_id':'SC01','trim_in':1,'duration':4,'dialogue_spans':[[0,3]]}]})
    def test_preview_approval_required(self):
        film.write(self.root/'.film/previews/p1.json',{'approved':False})
        with self.assertRaises(ValueError):deliver.build(self.root,'p1')
    def test_edits_invalidate_preview_confirmation(self):
        film.write(self.root/'edit.json',{})
        film.write(self.root/'.film/previews/p1.json',{'approved':True,'fingerprint':'old','edit':'edit.json'})
        with patch.object(deliver,'validate',return_value=(self.state,1,'new')):
            with self.assertRaises(ValueError):deliver.build(self.root,'p1')

    def test_nsdd_reservation_not_confused_with_actual(self):
        q=film.normalize_quote({'id':'n1','reservedPoints':12,'minPoints':5,'maxPoints':12})
        self.assertEqual(q['approval_points'],12)
        self.assertEqual(q['estimated_points'],5)
        self.assertNotIn('actual_points',q)

    def test_final_review_binds_rendered_bytes(self):
        (self.root/'film.mp4').write_bytes(b'original')
        film.write(self.root/'final-review.json',{'status':'awaiting_user_review','mp4_sha256':film.digest(b'original')})
        self.assertEqual(deliver.accept_delivery(self.root,'test user acceptance')['status'],'accepted')
        (self.root/'film.mp4').write_bytes(b'changed')
        with self.assertRaises(ValueError):deliver.accept_delivery(self.root,'old acceptance')

    def test_relink_moved_media_and_refuse_overwrite(self):
        delivery=self.root/'delivery';folder=delivery/'draft';folder.mkdir(parents=True)
        (delivery/'media.mp4').write_bytes(b'synthetic')
        film.write(folder/'draft_content.json',{'materials':[{'path':'old-location'}]})
        film.write(folder/'draft_meta_info.json',{})
        film.write(delivery/'draft-links.json',{'draft':'draft','bindings':[{'pointer':['materials',0,'path'],'relative':'media.mp4'}]})
        target=deliver.install_draft(delivery,self.root/'drafts')
        content=film.read(target/'draft_content.json')
        self.assertEqual(Path(content['materials'][0]['path']),target/'media.mp4')
        before=(target/'draft_content.json').read_bytes()
        with self.assertRaises(ValueError):deliver.install_draft(delivery,self.root/'drafts')
        self.assertEqual((target/'draft_content.json').read_bytes(),before)

    def test_depth_rejects_ordinary_video_model(self):
        self.spec['scenes'][0]['model']='video-model';film.write(self.root/'ordinary.json',self.spec)
        row=film.plan(self.root,self.state,'wrong-depth','depth','production','ordinary.json')
        film.approve_plan(self.root,self.state,'wrong-depth',row['fingerprint'],'test approval')
        with self.assertRaises(ValueError):film.quote_stage(self.root,self.state,'wrong-depth',self.factory)
        self.assertEqual(self.client.quote_calls,0)

if __name__=='__main__':unittest.main(verbosity=2)
