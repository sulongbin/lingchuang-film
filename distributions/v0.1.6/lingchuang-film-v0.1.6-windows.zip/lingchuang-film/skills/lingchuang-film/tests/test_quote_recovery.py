import copy
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch
from urllib.error import HTTPError, URLError
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'modules/lingchuang-video/scripts'))
import film
import lczyai
from production import ProductionClient
from nsdd import NsddClient

def error(status,code,message='server explanation',endpoint='/api/v1/production/runs'):
    return lczyai.ApiError(status,code,message,'POST',endpoint)

class Service:
    def __init__(self):
        self.failure=None;self.runs={};self.calls=[];self.refreshes=[];self.recovery_failure=None
    def models(self):return {'models':[{'id':'video','kind':'video','stage':'generate'}]}
    def quote(self,manifest):return {'quote_id':'q1','estimated_points':2,'items':[{'effective_parameters':{'duration':8}}]}
    def submit(self,q,confirmation):
        self.calls.append(q)
        if self.failure:raise self.failure
        return self.runs.setdefault(q,{'run_id':'run-'+q,'status':'queued'})
    def requote(self,q):
        if q in self.runs:raise error(409,'invalid_request')
        self.refreshes.append(q)
        return {'quote_id':'q2','estimated_points':3,'items':[{'effective_parameters':{'duration':8}}]}
    def recover_quote(self,q):
        if self.recovery_failure:raise self.recovery_failure
        if q in self.runs:return {'run':copy.deepcopy(self.runs[q])}
        return {'quote':self.requote(q),'verification':'server_atomic_refresh'}

class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        self.state=film.init(self.root,'commercial','offline');self.service=Service();self.factory=lambda *_:self.service
        film.write(self.root/'plan.json',{'scenes':[{'model':'video','scene_id':'SC01'}]})
        self.row=film.plan(self.root,self.state,'v1','video','production','plan.json')
        film.approve_plan(self.root,self.state,'v1',self.row['fingerprint'],'fixture plan approval')
        film.quote_stage(self.root,self.state,'v1',self.factory)
        film.approve_cost(self.root,self.state,'v1','q1',2,'fixture cost approval')
    def submit(self,retry=False):return film.submit(self.root,self.state,'v1',retry,self.factory)
    def reject(self,exc):
        self.service.failure=exc
        with self.assertRaises(ValueError):self.submit()
    def test_expired_refresh_reconfirm_submit(self):
        self.reject(error(409,'quote_expired'))
        self.assertEqual(self.row['status'],'requote_required')
        self.assertFalse(self.row['cost_approved'])
        film.refresh(self.root,self.state,'v1',self.factory)
        with self.assertRaises(ValueError):self.submit()
        film.approve_cost(self.root,self.state,'v1','q2',3,'fixture new quote approval')
        self.service.failure=None
        self.assertEqual(self.submit()['run_id'],'run-q2')
    def test_changed_quote_invalidates_old_confirmation(self):
        self.reject(error(409,'quote_changed'))
        self.assertEqual(self.row['status'],'requote_required')
        self.assertFalse(self.row['cost_approved'])
        with self.assertRaises(ValueError):film.approve_cost(self.root,self.state,'v1','q1',2,'stale')
    def test_balance_retry_same_quote(self):
        self.reject(error(402,'insufficient_points'))
        self.assertEqual(self.row['status'],'insufficient_balance')
        self.assertEqual(self.row['quote']['id'],'q1')
        self.assertTrue(self.row['cost_approved'])
        self.service.failure=None
        self.assertEqual(self.submit()['run_id'],'run-q1')
        self.assertEqual(self.service.refreshes,[])
    def test_timeout_replay_same_quote_exactly_one_run(self):
        self.service.runs['q1']={'run_id':'run-q1','status':'queued'}
        self.service.failure=TimeoutError('response lost')
        with self.assertRaises(TimeoutError):self.submit()
        with self.assertRaises(ValueError):film.refresh(self.root,self.state,'v1',self.factory)
        self.service.failure=None
        self.assertEqual(self.submit(True)['run_id'],'run-q1')
        self.submit();self.assertEqual(len(self.service.runs),1)
        self.assertEqual(self.service.calls,['q1','q1'])
    def test_ambiguous_errors_stay_unknown(self):
        for exc in [error(409,None,'报价已过期，请重新估价确认。'),error(409,'conflict'),error(503,'quote_expired'),error(402,None),error(402,'insufficient_points_at_settlement'),error(409,'quote_expired',endpoint='/api/v1/linhai/tasks')]:
            with self.subTest(error=str(exc)):
                self.row['status']='quoted';self.row['cost_approved']=True
                self.reject(exc);self.assertEqual(self.row['status'],'unknown')
                with self.assertRaises(ValueError):film.refresh(self.root,self.state,'v1',self.factory)
    def test_historical_unknown_recovered_only_by_server_refresh(self):
        self.row['status']='unknown'
        film.recover(self.root,self.state,'v1',self.factory)
        self.assertEqual(self.row['quote']['id'],'q2')
        self.assertFalse(self.row['cost_approved'])
        self.assertEqual(self.service.calls,[])
        self.assertEqual(self.row['history'][0]['id'],'q1')
    def test_historical_existing_run_recovers_original(self):
        self.row['status']='unknown';self.service.runs['q1']={'run_id':'original','status':'queued'}
        film.recover(self.root,self.state,'v1',self.factory)
        self.assertEqual(self.row['remote_id'],'original');self.assertEqual(self.service.refreshes,[])
    def test_historical_unverifiable_stays_unknown(self):
        self.row['status']='unknown';self.service.recovery_failure=error(409,'invalid_request')
        with self.assertRaises(ValueError):film.recover(self.root,self.state,'v1',self.factory)
        self.assertEqual(self.row['status'],'unknown');self.assertEqual(self.row['quote']['id'],'q1')

    def test_local_expiry_prevents_first_post(self):
        self.row['quote']['raw']['expires_at']=1
        with self.assertRaises(ValueError):self.submit()
        self.assertEqual(self.row['status'],'requote_required');self.assertEqual(self.service.calls,[])
        self.assertFalse(film.read(self.root/'.film/project.json')['stages']['v1']['cost_approved'])

    def test_balance_expired_requires_new_quote(self):
        self.reject(error(402,'insufficient_points'))
        self.row['quote']['raw']['expires_at']=1;self.service.failure=None
        with self.assertRaises(ValueError):self.submit()
        self.assertEqual(self.service.calls,['q1']);self.assertEqual(self.row['status'],'requote_required')
        film.refresh(self.root,self.state,'v1',self.factory)
        self.assertFalse(self.row['cost_approved'])

    def test_unknown_local_expiry_cannot_clear_uncertainty(self):
        self.row['status']='unknown';self.row['quote']['raw']['expires_at']=1
        with self.assertRaises(ValueError):self.submit()
        self.assertEqual(self.row['status'],'unknown')
        self.service.runs['q1']={'run_id':'original','status':'queued'}
        self.assertEqual(self.submit(True)['run_id'],'original')

    def test_refresh_response_loss_invalidates_old_fee(self):
        with patch.object(self.service,'requote',side_effect=TimeoutError('refresh lost')):
            with self.assertRaises(TimeoutError):film.refresh(self.root,self.state,'v1',self.factory)
        restored=film.read(self.root/'.film/project.json')['stages']['v1']
        self.assertFalse(restored['cost_approved']);self.assertEqual(restored['status'],'requote_required')
        with self.assertRaises(ValueError):self.submit()

    def test_unstructured_old_error_never_authorizes_reset(self):
        self.reject(ValueError('API 409：报价已过期，请重新估价确认。'))
        self.assertEqual(self.row['status'],'unknown')

    def test_error_state_redacts_secret(self):
        with patch.dict('os.environ',{'LCZYAI_API_KEY':'fixture-secret'}):
            self.reject(ValueError('failure fixture-secret Bearer arbitrary-token'))
            text=(self.root/'.film/project.json').read_text(encoding='utf-8')
            self.assertNotIn('fixture-secret',text);self.assertNotIn('arbitrary-token',text)

    def test_recovery_malformed_or_lost_proof_keeps_unknown(self):
        self.row['status']='unknown'
        for response in [{}, {'quote':{'quote_id':'q2','estimated_points':3}},
                         {'quote':{'quote_id':'q1','estimated_points':2},'verification':'server_atomic_refresh'}]:
            with patch.object(self.service,'recover_quote',return_value=response):
                with self.assertRaises(ValueError):film.recover(self.root,self.state,'v1',self.factory)
            self.assertEqual(self.row['status'],'unknown');self.assertEqual(self.row['quote']['id'],'q1')
        with patch.object(self.service,'recover_quote',side_effect=TimeoutError('lost')):
            with self.assertRaises(TimeoutError):film.recover(self.root,self.state,'v1',self.factory)
        self.assertEqual(film.read(self.root/'.film/project.json')['stages']['v1']['status'],'unknown')


class ClientErrorTests(unittest.TestCase):
    def client(self, cls=lczyai.Client):
        c=object.__new__(cls);c.base='http://localhost';c.secret='fixture-secret';c.opener=Mock()
        return c
    def test_http_fields_and_redaction_all_three_clients(self):
        for cls in (lczyai.Client,ProductionClient,NsddClient):
            with self.subTest(client=cls.__name__):
                c=self.client(cls)
                body={'code':'quote_expired','error':'changed-language fixture-secret Bearer hidden-token'}
                c.opener.open.side_effect=HTTPError('http://localhost',409,'Conflict',{},io.BytesIO(json.dumps(body).encode()))
                with self.assertRaises(lczyai.ApiError) as caught:c.api('POST','/api/v1/production/runs',{})
                e=caught.exception
                self.assertIsInstance(e,ValueError);self.assertEqual(e.http_status,409);self.assertEqual(e.code,'quote_expired')
                self.assertEqual(e.endpoint,'/api/v1/production/runs');self.assertEqual(e.method,'POST')
                public=json.dumps(e.as_dict())+str(e)
                self.assertNotIn('fixture-secret',public);self.assertNotIn('hidden-token',public)
    def test_nested_error_code(self):
        c=self.client();body={'error':{'code':'quote_changed','message':'changed'}}
        c.opener.open.side_effect=HTTPError('http://localhost',409,'Conflict',{},io.BytesIO(json.dumps(body).encode()))
        with self.assertRaises(lczyai.ApiError) as e:c.api('POST','/api/v1/production/runs',{})
        self.assertEqual(e.exception.code,'quote_changed')
    def test_html_500_is_unknown_and_not_body_leak(self):
        c=self.client();c.opener.open.side_effect=HTTPError('http://localhost',500,'error',{},io.BytesIO(b'<html>fixture-secret</html>'))
        with self.assertRaises(lczyai.ApiError) as e:c.api('POST','/api/v1/production/runs',{})
        self.assertEqual(e.exception.http_status,500);self.assertIsNone(e.exception.code)
        self.assertEqual(film.rejection_state(e.exception,'production'),'unknown')
        self.assertNotIn('fixture-secret',str(e.exception))
    def test_network_failure_remains_unknown(self):
        for exc in (TimeoutError('timeout'),URLError('lost')):
            c=self.client();c.opener.open.side_effect=exc
            with self.assertRaises(lczyai.ApiError) as e:c.api('POST','/api/v1/production/runs',{})
            self.assertIsNone(e.exception.http_status);self.assertEqual(film.rejection_state(e.exception,'production'),'unknown')
    def test_get_error_not_mistaken_for_submit_rejection(self):
        e=lczyai.ApiError(409,'quote_expired','x','GET','/api/v1/member')
        self.assertEqual(film.rejection_state(e,'production'),'unknown')


class RecoveryClientTests(unittest.TestCase):
    Q='11111111-1111-4111-8111-111111111111'
    Q2='22222222-2222-4222-8222-222222222222'
    R='33333333-3333-4333-8333-333333333333'
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
    def client(self,cls):
        c=object.__new__(cls);c.root=self.root;c.folder=self.root/'.lczyai'
        namespace={lczyai.Client:'',ProductionClient:'fullflow',NsddClient:'nsdd'}[cls]
        lczyai.save(c.folder/namespace/'quotes'/f'{self.Q}.json',{'quote':{'quote_id':self.Q,'id':self.Q,'estimated_points':2},'request':{},'fingerprint':'fixture'})
        return c
    def test_legacy_and_production_recovery_check_list_then_guarded_refresh(self):
        for cls in (lczyai.Client,ProductionClient):
            c=self.client(cls);calls=[]
            def api(method,url,*_):
                calls.append((method,url))
                if method=='GET':return {'runs':[],'total':0}
                self.assertEqual(url,f'/api/v1/production/quotes/{self.Q}/refresh')
                return {'quote_id':self.Q2,'estimated_points':3}
            c.api=api;result=c.recover_quote(self.Q)
            self.assertEqual(result['verification'],'server_atomic_refresh')
            self.assertEqual(calls[0],('GET','/api/v1/production/runs?page=1'))
            self.assertEqual(len(calls),2)
    def test_list_absence_and_server_rejection_not_proof(self):
        c=self.client(ProductionClient)
        c.api=Mock(side_effect=[{'runs':[],'total':0},error(409,'invalid_request')])
        with self.assertRaises(lczyai.ApiError):c.recover_quote(self.Q)
        self.assertEqual(c.api.call_count,2)
    def test_existing_run_never_refreshes(self):
        c=self.client(ProductionClient);run={'run_id':self.R,'quote_id':self.Q,'status':'processing'}
        c.api=Mock(side_effect=[{'runs':[run],'total':1},run])
        self.assertEqual(c.recover_quote(self.Q),{'run':run})
        self.assertTrue(all(call.args[0]=='GET' for call in c.api.call_args_list))
    def test_nsdd_server_intent_rejection_is_preserved(self):
        c=self.client(NsddClient);c.api=Mock(side_effect=error(409,None,endpoint=f'/api/v1/linhai/quotes/{self.Q}/refresh'))
        with self.assertRaises(lczyai.ApiError):c.recover_quote(self.Q)
        c.api.assert_called_once_with('POST',f'/api/v1/linhai/quotes/{self.Q}/refresh',{})

if __name__=='__main__':unittest.main()
