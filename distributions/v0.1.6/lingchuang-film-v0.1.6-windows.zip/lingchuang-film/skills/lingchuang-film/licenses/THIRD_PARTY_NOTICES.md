# 来源与分发声明

## 用户提供的创作模块

`modules/5min-drama-contest` 和 `modules/ai-film-general-skill` 来自用户提供的本机实际技能。2026-10-03，用户明确确认拥有两者及案例文字的客户分发授权。保留原内容、方法作者提及、案例来源与资源；本包不将其重新宣称为原创或赋予新的开源许可。逐文件摘要见 [来源记录](local-module-provenance.json)。模块内影视 IP 案例用于方法参考，不代表授予其中角色、商标或影视素材的其他使用权。

`modules/lingchuang-video` 来自用户指定的 v0.4.1 修复包。v0.1.1 在三个 Python 客户端增加结构化错误传递与服务端校验恢复，其余原模块资源保持。平台模型、接口及计费没有修改，不改变供应商协议或归属。

## 安装时取得的依赖

- pyJianYingDraft 0.3.0：Apache-2.0。[许可原文](pyJianYingDraft-LICENSE.txt)，上游 https://github.com/GuanYixuan/pyJianYingDraft 。本包通过固定版本依赖调用，不复制修改上游源码。草稿输出依赖该库自带模板。
- imageio-ffmpeg 0.6.0：BSD-2-Clause。[许可原文](imageio-ffmpeg-LICENSE.txt)，上游 https://github.com/imageio/imageio-ffmpeg 。
- FFmpeg：本包不附带二进制。客户可指定自己安装的版本，或通过 imageio-ffmpeg 的发行包取得；具体构建组件及许可以上游发行说明为准，不能把 FFmpeg 许可等同于 Python 包许可。
- pymediainfo、imageio、Pillow、numpy、uiautomation、comtypes：由 pip 按 requirements 解析安装，保留安装包自身 LICENSE/METADATA。本 ZIP 不重分发这些依赖的源码或二进制，也不覆盖其许可。

依赖安装需要网络，使用客户本机独立虚拟环境。没有将作者本机依赖目录放进 ZIP。

## Shotcraft 与声音

Shotcraft 首版不包含；本补丁不尝试获取源码、补依赖或集成。详见 [范围说明](../references/shotcraft.md)。没有打包任何来源或分发权不明确的第三方音效、音乐、样片、字体或品牌图片。

验证样例由本包脚本本地合成色块、线框和正弦测试音，无第三方媒体。样例不是艺术成片质量证明。
