# Windows 剪映交付

使用 [deliver.py](../scripts/deliver.py)，依赖见 [requirements.txt](../requirements.txt)。只处理本地已确认素材，不调用生成 API、不扣积分。不要操作用户现有草稿。

## 剪辑清单

在项目根创建 `edit.json`（示例结构见 [edit.example.json](../examples/edit.example.json)）。主轨按 shots 顺序组接，scene_id 从项目 selected 表读取最终资产。trim_in/duration 是源片入点和保留长度；dialogue_spans 是源片中已核对的完整台词时间范围，裁剪不得截断。未标注范围不能宣称程序已识别台词，Agent 须审听并确认。

独立 audio 条目用已选 asset_id，role 为 dialogue/music/sfx，start 是成片时间，source_in 是素材入点。默认保留视频原生声音，并抽出独立 WAV 原声音轨；它可能包含环境声和原配乐，不是人声分离。外部配音替换原声时由用户确认对应镜头 native_audio:false。配乐在对白时段按 music_duck 降音量，原生声音无对白标注时保守避让整个镜头。

subtitles 为实际核对的文本和成片时码，输出 SRT、MP4 烧录字幕及草稿可编辑文字轨。首版无自动 ASR、自动静音裁剪、音色替换或口型修复；不要声称这些已自动完成。原始素材复制进入交付目录，草稿引用原片及入出点，可再裁剪；MP4 会按指定画幅等比适配并保留完整画面。

## 短预览与成片

```powershell
# $skill 与 $project 按操作流程设置，python 使用安装好的虚拟环境。
python "$skill/scripts/deliver.py" preview --project "$project" --edit edit.json --seconds 8
# 播放返回 path，用户确认声音和字幕后：
python "$skill/scripts/deliver.py" approve-preview --project "$project" --preview PREVIEW_ID --note '用户确认声音与字幕样式'
python "$skill/scripts/deliver.py" build --project "$project" --preview PREVIEW_ID
```

最多 30 秒短预览；首版预览片从开头截取，可先将用户要验收的代表片段安排在专用预览清单，再在正式清单生成最终短预览确认。图片、视频或剪辑清单变化后摘要不匹配，必须重新预览。

build 创建全新的 `film-deliveries/随机ID/`，含 `film.mp4`、`subtitles.srt`、`media/`、草稿目录、路径绑定、来源与费用记录。build 的成片仍待全片预览，不等于用户最终验收。播放后检查全片是否漏镜、黑帧、声音截断、字幕越界；用户要求修改则新版本重新预览，不覆盖旧交付。转场首版支持硬切及已生成/确认的独立转场视频；不包含其他复杂本地转场动效。

全片预览获用户确认后，运行 `python "$skill/scripts/deliver.py" accept-delivery --delivery 'D:\交付目录' --note '用户确认整片采用'`，记录与成片摘要绑定的最终验收。`final-review.json` 初始为 awaiting_user_review；不要在用户尚未看片时执行确认。`costs.csv` 导出逐任务费用（无明细时为阶段费用），空实际积分表示未结算，不表示 0；不要与来源 JSON 再次相加。

## 换电脑与安装草稿

交付目录必须整体保留；绝对素材路径是在当前电脑生成的，移动后先重新绑定：

```powershell
python "$skill/scripts/deliver.py" relink --delivery 'D:\交付目录'
# 先通过剪映设置确认本机草稿根目录，不能凭示例猜测：
python "$skill/scripts/deliver.py" install-draft --delivery 'D:\交付目录' --drafts-root 'D:\已确认的剪映草稿根目录'
```

install-draft 复制完整素材到新的唯一草稿目录，拒绝同名覆盖，不编辑既有草稿或全局草稿数据库。安装后在剪映首页重新读取草稿，找到 lingchuang- 前缀的独立样例/工程。如果目标版本不自动列出新草稿，停止并记录，不能用删除用户草稿或猜测索引结构解决。

首版生成采用 pyJianYingDraft 0.3.0；FFmpeg 用于初剪预览及 MP4。草稿实际显示、字体样式和版本兼容仍须在目标 Windows 剪映逐项验证。MP4 与草稿字形/布局不承诺像素一致。不要用第三方 macOS 验证推断 Windows 可用。

## 验收记录

每份生成交付的 validation.json 默认 Windows 实机项为 false。只有实际完成后才记录：剪映版本、打开时间、无缺失素材、字幕编辑保存/重开结果、音轨音量编辑保存/重开结果、MP4 音画和完整性。可使用包内 [Windows 验收表](../examples/windows-acceptance.json)，填真实证据；没有验证就保持 pending。首版整体状态见 [status.md](status.md)。
