# 全流程客户端

使用包内 [scripts/production.py](../scripts/production.py)，Python 3.10+，无外部依赖。环境变量 LCZYAI_API_KEY 存会员密钥；不复制到清单、对话、日志或压缩包。清单中的素材及提示词路径均相对本地项目根目录；脚本路径取技能实际安装位置。

下面命令为模板，`<技能路径>`、`<项目>`、`<quote_id>`、`<run_id>` 都必须替换，含空格的路径须加引号，尖括号不能原样执行。可直接修改路径的 PowerShell 示例见 [API 文档](api-fullflow.md)。`--project` 必须位于子命令之前。

```sh
python <技能路径>/scripts/production.py --project <项目> models
python <技能路径>/scripts/production.py --project <项目> quote production-v2.json
# 展示清单，取得本次费用确认后：
python <技能路径>/scripts/production.py --project <项目> submit <quote_id> --confirm <quote_id>
python <技能路径>/scripts/production.py --project <项目> status <run_id>
python <技能路径>/scripts/production.py --project <项目> download <run_id>
```

将下面示例按当前项目修改后保存为项目根目录的 `production-v2.json`，不是在包内寻找该文件。`prompts/CHAR01.txt` 和 `assets/reference.png` 是需自行准备的本地项目文件；也可用 `prompt` 直接写提示词，并在纯文生图时省略 `images`。

```json
{"project_name":"我的作品","script_revision":"v1","scenes":[
 {"scene_id":"CHAR01","model":"从 models 复制图片模型 id","prompt_file":"prompts/CHAR01.txt","images":["assets/reference.png"],"parameters":{"size":"1024x1024"}}
]}
```

包内模型记录见 [已适配与未适配模型](adapted-models.md)，实时会员目录优先；nsdd 模型按 [nsdd 接入](nsdd.md) 使用专用客户端。

每镜先选目录中的 id，再按其 parameters 填字段，不能原样提交占位符。本地图片/视频/声音用 images/videos/audios；已有素材 ID 或前序返回 result:... 用 images_asset_ids/videos_asset_ids/audios_asset_ids。纯配乐 parameters 可为 {"isInstrumental":true,"format":"mp3"}；配音 prompt 是口述文本，parameters.audio_config 为目录允许参数。普通视频 duration/quality/ratio 在镜头顶层，Veo 的 generationType 在 parameters 中。完整协议、能力与错误见 [API 文档](api-fullflow.md)。

源片验收后的后处理使用 reviewed:true，与 source_task_id（本入口任务）或 videos_asset_ids（跨入口结果）。保留原结果和明确的 asset_version。报价不生成，submit 必须确认，status/download 不重新生成。返回每项 estimated_points、actual_points_cost、settlement_status 及 canvas；null 表示待结算。配音预扣最大时长，按真实原始音频时长结算，不把预扣直接当成消耗。

相同内容 quote 会复用本地报价记录。过期报价用 requote <quote_id>；服务端拒绝刷新已提交报价。主动重做需新镜头/资产版本并确认费用。混合流程按资产依赖分批：图片完成再用结果 ID 生成视频，视频验收再超分；不能让后一任务引用尚未完成的素材。

新旧 API 共享会员身份与画布绑定；保留 .lczyai 全部记录。第一次建作品时先串行提交首批并验证画布，再跨入口追加。画布容量满了由用户决定新画布，不能删除旧资产。独立音效、视频延长等未适配项目必须按接口限制停止。技能负责 API 生产，上层技能负责剪映草稿、字幕与本地剪辑。
