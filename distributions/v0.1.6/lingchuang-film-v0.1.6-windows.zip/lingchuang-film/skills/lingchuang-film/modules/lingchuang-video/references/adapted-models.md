# 已适配与未适配模型

核对时间：2026-10-03。26 个全流程模型 + 10 个 nsdd 模型，参数合同已适配并模拟测试；不代表逐个付费生成验收。运行时目录优先。

| 入口 | 模型 | 类型 | 协议 ID |
|---|---|---|---|
| production.py | gpt-image-2-1K | image / image | `apilio:gpt-image-2-all` |
| production.py | Veo 3.1 Fast | video / generate | `grok------api:veo3.1-fast` |
| production.py | gpt-image-2-4K | image / image | `apilio:gpt-image-2` |
| production.py | Grok Imagine Video 1.5 | video / generate | `apilio:grok-imagine-video-1.5` |
| production.py | GROK Video 多图版 | video / generate | `grok------api:grok-video` |
| production.py | GPT-Image 2 · 多米 | image / image | `grok------api:gpt-image-2` |
| production.py | GROK Video 1.5 720P | video / generate | `grok------api:grok-video-1.5` |
| production.py | GPT-Image 2.5Flare · 多米 | image / image | `grok------api:gpt-image-2.5-flare` |
| production.py | GPT-Image 2.5Sunburst · 多米 | image / image | `grok------api:gpt-image-2.5-sunburst` |
| production.py | seedance-2.0-mini | video / generate | `channel-msn7b8sr:doubao-seedance-2-0-mini-260615` |
| production.py | Nano Banana 1 | image / image | `grok------api:gemini-2.5-flash-image` |
| production.py | wan3.0-video | video / generate | `apilio:wan3.0-video` |
| production.py | Nano Banana Pro | image / image | `grok------api:gemini-3-pro-image-preview` |
| production.py | Nano Banana 2 | image / image | `grok------api:gemini-3.1-flash-image-preview` |
| production.py | WAN 3.0 · 词元流墟 | video / generate | `tokenmarket:wan3.0-video` |
| production.py | Seedance 2.5 | video / generate | `channel-msn7b8sr:doubao-seedance-2-5-260628` |
| production.py | Nano Banana 2 Lite | image / image | `grok------api:gemini-3.1-flash-lite-image-preview` |
| production.py | Veo 3.1 Pro | video / generate | `grok------api:veo3.1-pro` |
| production.py | RH 视频转深度视频 | video / video_depth | `runninghub-video:rh-video-depth-converter` |
| production.py | MiniMax H3 Max Turbo · 首尾帧 | video / generate | `runninghub-video:minimax-h3-max-turbo-first-last` |
| production.py | MiniMax H3 · 多模态参考 | video / generate | `runninghub-video:minimax-h3-ref2va-advanced` |
| production.py | RH 视频超分 | video / upscale | `runninghub-video:rh-video-upscaler` |
| production.py | H3 专用超分 2K | video / h3_2k | `runninghub-video:minimax-h3-regeneration-2k` |
| production.py | MiniMax Music 2.6 | audio / music | `runninghub-video:minimax-music-2.6` |
| production.py | 火山字幕擦除 · 标准版 | video / subtitle_erase | `runninghub-video:volc-subtitle-erase` |
| production.py | 豆包音频生成 1.0 | audio / speech | `doubao-speech:seed-audio-1.0` |
| nsdd.py | GK-video-3.5 · nsdd | video | `linhai:gk-video-3.5` |
| nsdd.py | GK-video-3 · nsdd | video | `linhai:gk-video-3` |
| nsdd.py | 海螺 H3 参考生 · nsdd | video | `linhai:hailuo-h3-cankaosheng` |
| nsdd.py | 海螺 H3 全能参考 · nsdd | video | `linhai:hailuo-h3-quannengcankao` |
| nsdd.py | 海螺 H3 文生视频 · nsdd | video | `linhai:hailuo-h3` |
| nsdd.py | MiniMax H3 · nsdd | video | `linhai:minimax-h3` |
| nsdd.py | SD 2.5 全能参考 按秒 · nsdd | video | `linhai:seedance-2.5-anmiao-quannengcankao` |
| nsdd.py | SD 2.5 满血版 按秒 · nsdd | video | `linhai:seedance-2.5-guanfang-anmiao` |
| nsdd.py | TT Image 2.5 · nsdd | image | `linhai:tt-image-2.5` |
| nsdd.py | 视频超分 · nsdd | video | `linhai:video-enhance` |

## 未适配

/api/v1/models 的 unavailable 是该入口未接通的项目，其中 nsdd 的 10 项须改用专用入口，不表示全平台都不可用。排除专用入口后：

- `runninghub-llm:deepseek/deepseek-v4.1-flash`：此模型尚无会员生产适配；禁止直接提交。
- `runninghub:qwen/qwen3.8-flash-next`：此模型尚无会员生产适配；禁止直接提交。
- `apilio:glm-5.3-flash`：此模型尚无会员生产适配；禁止直接提交。
- `runninghub:rhart-video-g`：此模型尚无会员生产适配；禁止直接提交。
- `tokenmarket:gemini-3.8-flash`：此模型尚无会员生产适配；禁止直接提交。
- `runninghub-llm:deepseek/deepseek-v4-flash-vision-exp`：此模型尚无会员生产适配；禁止直接提交。
- `nananobanana:ant-2-text-2-video`：此模型尚无会员生产适配；禁止直接提交。
- `bltcy:gpt-5.6-luna`：此模型尚无会员生产适配；禁止直接提交。
- `bltcy:gpt-5.6-terra`：此模型尚无会员生产适配；禁止直接提交。
- `runninghub:wan2.2-character-motion-transfer`：此模型尚无会员生产适配；禁止直接提交。
- `bltcy:gpt-5.6-sol`：此模型尚无会员生产适配；禁止直接提交。
- `tokenmarket:deepseek-v4-pro`：此模型尚无会员生产适配；禁止直接提交。
- `apilio:gpt-6-astra`：此模型尚无会员生产适配；禁止直接提交。
- `apilio:gpt-6-sol`：此模型尚无会员生产适配；禁止直接提交。
- `apilio:gpt-6-luna`：此模型尚无会员生产适配；禁止直接提交。

独立音效未核实；SD 参考视频附加计费和视频延长尚未适配。普通超分可用分辨率及 H3 专用 2K 条件按实时目录判断。
