"""Lingchuang member production client. Python 3.10+, standard library only."""
import argparse
import hashlib
import json
import mimetypes
import os
import re
from pathlib import Path
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def sha(data):
    return hashlib.sha256(data).hexdigest()


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError("API 重定向已拒绝，避免把密钥发送到其他地址。")


def redact(value, secret=""):
    text = str(value)
    if secret:
        text = text.replace(secret, "[已隐藏]")
    return re.sub(r"Bearer\s+\S+|lc_live_[A-Za-z0-9_-]+", "[已隐藏]", text, flags=re.I)


class ApiError(ValueError):
    """Structured and redacted; remains compatible with existing ValueError handlers."""
    def __init__(self, status, code, message, method, endpoint, secret=""):
        self.http_status = status
        self.code = redact(code, secret) if isinstance(code, str) else None
        self.message = redact(message, secret)
        self.method = method
        self.endpoint = redact(endpoint, secret)
        super().__init__(f"API {status}：{self.message}" if status is not None else self.message)

    def as_dict(self):
        return {"http_status": self.http_status, "code": self.code, "message": self.message,
                "method": self.method, "endpoint": self.endpoint}


class Client:
    def __init__(self, project):
        self.root = Path(project).resolve(strict=True)
        if not self.root.is_dir():
            raise ValueError("项目目录不存在。")
        self.folder = self.root / ".lczyai"
        self.base = os.environ.get("LCZYAI_API_BASE", "https://chat.lczyai.com").rstrip("/")
        parsed = urllib.parse.urlparse(self.base)
        local = parsed.scheme == "http" and parsed.hostname in ("127.0.0.1", "localhost")
        if self.base != "https://chat.lczyai.com" and not local:
            raise ValueError("仅允许灵创智影正式地址或本机联调地址。")
        self.secret = os.environ.get("LCZYAI_API_KEY", "")
        if not self.secret:
            raise ValueError("请先在本机环境变量 LCZYAI_API_KEY 配置会员密钥，不要发到对话中。")
        self.opener = urllib.request.build_opener(NoRedirect())
        self.member_id = self.api("GET", "/api/v1/member")["member"]["id"]
        binding = self.folder / "member.json"
        if binding.exists() and load(binding) != {"base": self.base, "member_id": self.member_id}:
            raise ValueError("此项目已绑定另一会员或服务地址，请使用独立项目目录。")
        save(binding, {"base": self.base, "member_id": self.member_id})

    def api(self, method, endpoint, body=None, content_type="application/json"):
        if not endpoint.startswith("/api/v1/"):
            raise ValueError("不允许调用非会员 API。")
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode() if body is not None else None
        req = urllib.request.Request(self.base + endpoint, data=data, method=method,
                                     headers={"Authorization": "Bearer " + self.secret, "Content-Type": content_type})
        try:
            with self.opener.open(req, timeout=120) as response:
                return json.load(response)
        except urllib.error.HTTPError as e:
            code = None
            try:
                payload = json.loads(e.read())
                if not isinstance(payload, dict):
                    payload = {}
                error = payload.get("error", "请求失败")
                code = payload.get("code")
                if isinstance(error, dict):
                    code = code or error.get("code")
                    message = error.get("message", "请求失败")
                else:
                    message = error if isinstance(error, str) else "请求失败"
            except (ValueError, UnicodeDecodeError):
                message = "服务暂不可用"
            finally:
                e.close()
            raise ApiError(e.code, code, message, method, endpoint, self.secret) from None
        except (TimeoutError, urllib.error.URLError):
            raise ApiError(None, None, "网络请求未完成。提交阶段请核对或重放原报价，勿重新估价生成。", method, endpoint, self.secret) from None

    def local(self, relative):
        file = (self.root / relative).resolve(strict=True)
        if not file.is_relative_to(self.root) or not file.is_file():
            raise ValueError("素材与脚本须位于本次项目目录内。")
        return file

    def upload(self, relative):
        file = self.local(relative)
        mime = mimetypes.guess_type(file.name)[0] or ""
        if not (mime.startswith("image/") or mime.startswith("video/")):
            raise ValueError("本版本地上传支持图片和视频，音频请使用平台已有素材 ID。")
        if file.stat().st_size > 120 * 1024 * 1024:
            raise ValueError("单个素材超过 120MB。")
        content = file.read_bytes()
        cache_path = self.folder / "uploads.json"
        cache = load(cache_path) if cache_path.exists() else {}
        key = sha(content) + ":" + mime
        if key in cache:
            return cache[key]
        boundary = "lczyai-" + uuid.uuid4().hex
        # Use an ASCII transport name; the manifest retains the original local name.
        filename = sha(content)[:16] + file.suffix.lower()
        body = (f'--{boundary}\r\nContent-Disposition: form-data; name="files"; filename="{filename}"\r\n'
                f'Content-Type: {mime}\r\n\r\n').encode() + content + f"\r\n--{boundary}--\r\n".encode()
        result = self.api("POST", "/api/v1/materials/uploads", body, "multipart/form-data; boundary=" + boundary)
        cache[key] = result["materials"][0]["id"]
        save(cache_path, cache)
        return cache[key]

    def models(self):
        return self.api("GET", "/api/v1/models")

    def canvas_key(self):
        file = self.folder / "canvas.json"
        if file.exists():
            value = load(file)["canvas_key"]
            self.identifier(value)
            return value
        value = str(uuid.uuid4())
        save(file, {"canvas_key": value})
        return value

    def join_canvas(self, run_id, target_run):
        self.identifier(run_id)
        self.identifier(target_run)
        result = self.api("POST", "/api/v1/production/runs/" + run_id + "/canvas", {"target_run_id": target_run})
        save(self.folder / "runs" / (run_id + ".json"), result)
        save(self.folder / "canvas.json", {"canvas_key": result["canvas"]["canvas_key"]})
        self.status(target_run)
        return result

    def prepare(self, manifest):
        spec = load(self.local(manifest))
        models = {m["id"]: m for m in self.models()["models"]}
        defaults = spec.get("workflow", {}).get("generate", {})
        after = spec.get("workflow", {}).get("after_review")
        if after and (after.get("model") not in models or not models[after["model"]].get("reviewRequired")):
            raise ValueError("后续步骤必须选择模型列表中需要验收的视频处理模型。")
        scenes, fingerprints = [], []
        # Validate every local file and model before uploading the first asset.
        for entry in spec.get("scenes", []):
            row = {**defaults, **entry}
            model = models.get(row.get("model"))
            if not model or model["stage"] != "generate":
                raise ValueError("首次生成模型无效，请先查看 models 返回的可用模型。")
            if after and models[after["model"]]["stage"] == "h3_2k" and model.get("outputQuality") != "768P":
                raise ValueError("H3 专用 2K 后续步骤只兼容 H3 多模态 768P 原视频。")
            prompt = self.local(row["prompt_file"]).read_text(encoding="utf-8-sig") if row.get("prompt_file") else row.get("prompt", "")
            script = self.local(row["script_file"]).read_text(encoding="utf-8-sig") if row.get("script_file") else row.get("script", "")
            files = row.get("images", []) + row.get("videos", [])
            fingerprints += [{"path": f, "sha256": sha(self.local(f).read_bytes())} for f in files]
            if row.get("quality") and row["quality"] not in model["qualities"]:
                raise ValueError("所选模型不支持清单中的视频清晰度；不要从图片规格推定视频为 4K。")
            if row.get("duration") not in model["durations"]:
                raise ValueError("镜头时长不受支持；请确认脚本或另选模型，不能自动截短。")
            for kind in ("images", "videos", "audios"):
                if len(row.get(kind, [])) > model[kind]:
                    raise ValueError(f"参考数量超过模型 {kind} 上限，不能自动丢弃参考图。")
            scenes.append({**row, "prompt": prompt, "script": script})
        if not 1 <= len(scenes) <= 20:
            raise ValueError("每批需要 1–20 个镜头。")
        # Keep old fingerprints valid: preparing an already submitted plan must
        # still recover its original quote, even after the canvas feature update.
        fingerprint = sha(json.dumps({"spec": spec, "scenes": scenes, "files": fingerprints}, ensure_ascii=False, sort_keys=True).encode())
        index = self.folder / "plans" / (fingerprint + ".json")
        if index.exists():
            return load(index)["quote"]
        plan = {"project_name": spec["project_name"], "script_revision": spec["script_revision"], "canvas_key": self.canvas_key(), "scenes": []}
        for row in scenes:
            plan["scenes"].append({k: row[k] for k in ("scene_id", "model", "duration", "quality", "ratio", "prompt", "script") if k in row})
            plan["scenes"][-1].update({"images": [self.upload(p) for p in row.get("images", [])], "videos": [self.upload(p) for p in row.get("videos", [])], "audios": row.get("audios", [])})
        quote = self.api("POST", "/api/v1/production/quotes", plan)
        document = {"quote": quote, "request": plan, "workflow": spec.get("workflow", {}), "fingerprint": fingerprint}
        save(index, document)
        save(self.folder / "quotes" / (quote["quote_id"] + ".json"), document)
        return quote

    def quote_document(self, quote_id):
        self.identifier(quote_id)
        return load(self.folder / "quotes" / (quote_id + ".json"))

    @staticmethod
    def identifier(value):
        if str(uuid.UUID(value)) != value:
            raise ValueError("任务或报价编号无效。")

    def submit(self, quote_id, confirmed):
        doc = self.quote_document(quote_id)
        if confirmed != quote_id:
            raise ValueError("必须先让会员确认费用，再通过 --confirm 原报价编号提交。")
        result = self.api("POST", "/api/v1/production/runs", {"quote_id": quote_id, "confirmed": True,
                          "accepted_estimated_points": doc["quote"]["estimated_points"]})
        save(self.folder / "runs" / (result["run_id"] + ".json"), result)
        return result

    def status(self, run_id):
        self.identifier(run_id)
        result = self.api("GET", "/api/v1/production/runs/" + run_id)
        save(self.folder / "runs" / (run_id + ".json"), result)
        return result

    def next_quote(self, run_id, selected, reviewed):
        if not reviewed or not selected:
            raise ValueError("请先让会员验收，明确选择通过的镜头，再加 --reviewed。")
        run = self.status(run_id)
        doc = self.quote_document(run["quote_id"])
        stage = doc.get("workflow", {}).get("after_review")
        if not stage:
            raise ValueError("项目未设置后续处理模型，请先确认会员需要的流程。")
        if len(set(selected)) != len(selected):
            raise ValueError("验收镜头编号重复。")
        items = {i["scene_id"]: i for i in run["items"]}
        scenes = []
        for scene_id in selected:
            item = items.get(scene_id)
            if not item or item["status"] != "success":
                raise ValueError("只能对本批已成功且会员已验收的镜头申请后续报价。")
            scenes.append({"scene_id": scene_id, "model": stage["model"], "quality": stage.get("quality", "2K"),
                           "source_task_id": item["task_id"], "reviewed": True})
        request = {"project_name": run["project_name"] + " · 验收后处理", "script_revision": run["script_revision"], "scenes": scenes}
        fingerprint = sha(json.dumps(request, sort_keys=True).encode())
        index = self.folder / "plans" / (fingerprint + ".json")
        if index.exists():
            return load(index)["quote"]
        request["canvas_key"] = run.get("canvas", {}).get("canvas_key") or self.canvas_key()
        quote = self.api("POST", "/api/v1/production/quotes", request)
        saved = {"quote": quote, "request": request, "workflow": {}, "fingerprint": fingerprint}
        save(index, saved)
        save(self.folder / "quotes" / (quote["quote_id"] + ".json"), saved)
        return quote

    def find_quote_run(self, quote_id):
        self.identifier(quote_id)
        page = 1
        while True:
            runs = self.api("GET", "/api/v1/production/runs?page=" + str(page))
            for run in runs["runs"]:
                if run["quote_id"] == quote_id:
                    return self.status(run["run_id"])
            if page * 20 >= runs["total"]:
                return None
            page += 1

    def recover_quote(self, quote_id):
        run = self.find_quote_run(quote_id)
        if run is not None:
            return {"run": run}
        # List absence is NOT proof. Only the atomic server refresh may release
        # the old quote after checking runId and marking it superseded.
        return {"quote": self.requote(quote_id), "verification": "server_atomic_refresh"}

    def requote(self, quote_id):
        doc = self.quote_document(quote_id)
        quote = self.api("POST", "/api/v1/production/quotes/" + quote_id + "/refresh", {})
        doc["quote"] = quote
        save(self.folder / "quotes" / (quote["quote_id"] + ".json"), doc)
        save(self.folder / "plans" / (doc["fingerprint"] + ".json"), doc)
        return quote

    def download(self, run_id):
        result = self.status(run_id)
        outputs = []
        for item in result["items"]:
            if item["status"] != "success":
                continue
            for i, url in enumerate(item["videos"]):
                parsed = urllib.parse.urlparse(url)
                if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
                    raise ValueError("返回的视频地址不安全。")
                target = self.root / "outputs" / run_id / (item["scene_id"] + f"_{i+1}.mp4")
                target.parent.mkdir(parents=True, exist_ok=True)
                if not target.exists():
                    temp = target.with_suffix(".part")
                    # No member API credential is sent to the media host.
                    with self.opener.open(url, timeout=120) as response, temp.open("wb") as output:
                        while chunk := response.read(1024 * 1024):
                            output.write(chunk)
                    temp.replace(target)
                outputs.append(str(target))
        return {"files": outputs, "note": "文件已下载；内容、时长与画质仍需人工/媒体检测验收。"}


def main():
    parser = argparse.ArgumentParser(description="灵创智影会员视频生产：估价、确认提交、查询、验收后处理")
    parser.add_argument("--project", required=True, help="会员本地项目根目录")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("models")
    p = sub.add_parser("prepare");p.add_argument("manifest")
    p = sub.add_parser("submit");p.add_argument("quote_id");p.add_argument("--confirm", required=True)
    for command in ("status", "download"):
        p = sub.add_parser(command);p.add_argument("run_id")
    p = sub.add_parser("next-quote");p.add_argument("run_id");p.add_argument("--scenes", nargs="+", required=True);p.add_argument("--reviewed", action="store_true")
    p = sub.add_parser("requote");p.add_argument("quote_id")
    p = sub.add_parser("join-canvas");p.add_argument("run_id");p.add_argument("--target-run", required=True)
    args = parser.parse_args()
    try:
        client = Client(args.project)
        if args.command == "models": result = client.models()
        elif args.command == "prepare": result = client.prepare(args.manifest)
        elif args.command == "submit": result = client.submit(args.quote_id, args.confirm)
        elif args.command == "status": result = client.status(args.run_id)
        elif args.command == "next-quote": result = client.next_quote(args.run_id, args.scenes, args.reviewed)
        elif args.command == "requote": result = client.requote(args.quote_id)
        elif args.command == "join-canvas": result = client.join_canvas(args.run_id, args.target_run)
        else: result = client.download(args.run_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (ValueError, OSError, KeyError) as e:
        message = str(e)
        secret = os.environ.get("LCZYAI_API_KEY", "")
        print("失败：" + (message.replace(secret, "[已隐藏]") if secret else message), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
