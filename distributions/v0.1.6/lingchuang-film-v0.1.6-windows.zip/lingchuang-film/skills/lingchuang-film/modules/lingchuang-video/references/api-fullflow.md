# 灵创智影会员全流程生产 API · 文档包 v0.4.1

文档补丁日期：2026-10-03；v0.4.1 仅修正文档引用和调用示例，接口与计费逻辑保持 v0.4.0。适配范围以两个实时会员目录为准；“已适配”表示参数、任务、计费和结果经过模拟测试，**不表示逐模型付费生成已实测**。新增 nsdd 入口保留历史协议名称，界面统一显示 nsdd。

## 1. 鉴权与调用边界

基础地址 `https://chat.lczyai.com`，所有 `/api/v1` 请求使用 `Authorization: Bearer <会员自己的 API Key>`。不要向 OSS 下载域名传此请求头。供应商密钥仅留服务器。

报价、上传、提交和实际执行均检查会员服务/容量权限；提交检查报价总额对应余额，各生成服务继续原子冻结/结算积分。查询、下载只允许访问本人任务，不产生新的生成请求或重复扣费；查询可促使已有任务继续恢复与完成原结算。密钥过期、撤销或账号停用返回 401/403；已被平台接受的任务保留状态和原请求编号。

旧密钥继续可用，原密钥的 `scopes` 是历史描述信息，不是新增的可配置细粒度授权体系；实际权限仍由对应会员和平台生成权限控制。

## 2. 接入目录

调用 `GET /api/v1/models` 动态发现。`models` 仅列当前会员允许使用的已适配项，`unavailable` 列未适配/无权限的原因。新增配置不会因出现在公开目录中就自动获得适配。

包内模型清单见 [已适配与未适配模型](adapted-models.md)。该清单是发布时记录，**实时会员目录优先**：全流程查询 `GET /api/v1/models`，nsdd 查询 `GET /api/v1/linhai/models`；模型权限、参数、素材限制与可用状态以对应目录为准。nsdd 使用 [专用客户端说明](nsdd.md)，不能直接交给全流程客户端。下列表格属于全流程入口的发布记录，正式提交必须重新取得报价。

### 图片：9 条

| 模型 ID | 用途 |
| --- | --- |
| `apilio:gpt-image-2-all` | 图片资产/分镜图 |
| `apilio:gpt-image-2` | 图片资产/分镜图 |
| `grok------api:gpt-image-2` | 图片资产/分镜图 |
| `grok------api:gpt-image-2.5-flare` | 图片资产/分镜图 |
| `grok------api:gpt-image-2.5-sunburst` | 图片资产/分镜图 |
| `grok------api:gemini-2.5-flash-image` | 图片资产/分镜图 |
| `grok------api:gemini-3-pro-image-preview` | 图片资产/分镜图 |
| `grok------api:gemini-3.1-flash-image-preview` | 图片资产/分镜图 |
| `grok------api:gemini-3.1-flash-lite-image-preview` | 图片资产/分镜图 |

最多 6 张有序参考图，禁止视频/音频输入。每个 scene 调用一次原图片服务，按平台固定积分定价。默认 `parameters.size="auto"`，不默认指定 4K。显式尺寸为 16 的倍数，边长 64–3840，总像素不超过 8294400，且受该模型开放的 1K/2K/4K 档位限制。尺寸遵循原图片服务/供应商的尺寸或比例映射，不承诺自定义像素值必然原样输出；图片比例请通过 size 指定，不使用视频的 ratio/quality/duration。

### 视频与后处理：15 条

| 模型 ID | 接入范围/约束 |
| --- | --- |
| `runninghub-video:minimax-h3-max-turbo-first-last` | 1–2 张图片，首帧必需；比例跟随首帧 |
| `runninghub-video:minimax-h3-ref2va-advanced` | 最多 9 图、3 视频、3 音频，至少一项；768P |
| `runninghub-video:rh-video-upscaler` | 一条已验收原视频，沿用原时长；原超分取整/最低时长规则保持 |
| `runninghub-video:minimax-h3-regeneration-2k` | 本人成功 H3 多模态原任务；验收后单独报价；复用原参数生成 2K |
| `runninghub-video:rh-video-depth-converter` | 一条已验收原视频；灰度深度结果；此次 API 按付费规则 |
| `runninghub-video:volc-subtitle-erase` | 一条已验收原视频；字幕擦除；按输入时长规则 |
| `grok------api:veo3.1-fast` | TEXT / FIRST&LAST / REFERENCE |
| `grok------api:veo3.1-pro` | TEXT / FIRST&LAST / REFERENCE |
| `grok------api:grok-video` | 文字、最多 7 图；720P |
| `grok------api:grok-video-1.5` | 文字、最多 7 图；720P |
| `apilio:grok-imagine-video-1.5` | 文字、最多 3 图；多图时禁止 1080P，避免自动降档 |
| `apilio:wan3.0-video` | 本次开放文字、最多 3 图；视频/音频参考未开放 |
| `tokenmarket:wan3.0-video` | 文字、最多 3 图；视频/音频参考不支持 |
| `channel-msn7b8sr:doubao-seedance-2-0-mini-260615` | 最多 3 图、3 视频、3 音频，复用官方通道参数 |
| `channel-msn7b8sr:doubao-seedance-2-5-260628` | 最多 3 图、3 视频、3 音频，复用官方通道参数 |

时长和清晰度以目录 `durations/qualities` 为准，报价严格校验，不截短、不自动降档。Veo 首尾帧模式 1–2 图；参考图模式 1–3 图且仅 16:9；文字模式不能带图。API 不接受视频延长 EXTEND、免费额度开关或供应商私有参数。

`native_audio=true`：当前适配已知具有原生声音的 H3/Seedance；`null`：本接口未确认，不能当作支持或不支持。当前未开放原生声音的独立开关。参考数量是本次适配的上限；未声明的上游媒体时长、大小限制不能由技能包自行猜测，供应商仍可能拒绝素材。

### 声音：2 条

| 模型 ID | 参数和计费 |
| --- | --- |
| `runninghub-video:minimax-music-2.6` | 歌曲/纯音乐；lyrics ≤3500，prompt ≤2000；平台固定积分 |
| `doubao-speech:seed-audio-1.0` | 配音提示词 ≤3000；最多 1 图或 3 音频/公开音色，不混用；按原始音频秒数计费 |

配音参考图片为 JPEG/PNG/WebP，1KB–10MB；参考音频 WAV/MP3/Ogg Opus，≤10MB、>0 且 ≤30 秒。配音按现有服务最多 120 秒的金额预冻结，报价 `pricing_basis="maximum_reservation"`；实际按上游 `original_duration` 结算并退差额。不得把预估上限当成确定的最终消耗。

音乐 `parameters`：`isInstrumental`、`lyrics`、`lyricsOptimizer`、`format`（mp3/wav/pcm）、`sampleRate`（16000/24000/32000/44100）、`bitrate`（32000/64000/128000/256000）；频率和码率按目录字符串枚举提交。歌曲必须有 lyrics，纯音乐必须有 prompt。

配音 `parameters`：`speakers`（公开音色 ID 数组）和 `audio_config`。支持格式及采样率见 `parameter_schema`；speech_rate/loudness_rate 为 -50..100 整数，pitch_rate 为 -12..12，enable_subtitle 为布尔值。字幕文件整理/编辑仍由本地技能负责。

### 明确未适配

- `runninghub:wan2.2-character-motion-transfer`：现有万相动作迁移使用另一套工作流输入和计费，不能按普通视频生成提交。
- `nananobanana:ant-2-text-2-video`：现有服务会根据参考视频改变所用模型，需要进一步适配切换后的报价合同。
- `runninghub:rhart-video-g`：通用 RunningHub 入口尚未建立该模型的完整能力约束。
- 公开目录中的 12 个 LLM：脚本在本地 Codex 完成，本次媒体生产 API 不接入聊天模型。
- 独立音效：代码中虽有“人物配音与音效”描述，但没有可独立确认的音效接口、参数与计费合同。返回 `sound_effects.adapted=false`，不以配乐能力推定支持。

## 3. 接口流程

| 方法与路径 | 行为 |
| --- | --- |
| GET `/api/v1/models` | 已适配目录、参数、费用规则、未适配原因 |
| GET `/api/v1/member` | Key 所属会员 ID/名称 |
| POST `/api/v1/materials/uploads` | multipart `files`；每次最多 3 个，每个 ≤120MB；返回本人素材 ID；新增音频支持 |
| POST `/api/v1/production/quotes` | 校验/估价，不生成、不冻结积分 |
| POST `/api/v1/production/runs` | 明确确认报价后排队，202 返回 |
| GET `/api/v1/production/runs/:id` | 只读批次状态和逐任务费用 |
| GET `/api/v1/production/runs?page=1` | 本人批次列表，每页 20 |
| GET `/api/v1/production/tasks/:id` | 只读单任务、结果、费用、画布 |
| GET `/api/v1/production/tasks/:id/results/:kind/:index` | 本人结果校验后 302 到媒体地址；kind 为 images/videos/audios，index 从 0 开始 |
| POST `/api/v1/production/runs/:id/canvas` | 保留旧接口：完成批次归入另一本人批次画布 |

上传完成应保存 `materials[].id` 与本地资产文件哈希的映射。图片/视频/声音结果返回 `result:<task_id>:<images|videos|audios>:<index>` 素材 ID，可直接放入下一批的 images/videos/audios，无需重新上传。所有 ID 均检查会员归属和类型，不能提交任意 URL 作为参考。

### 报价请求

```json
{
  "workflow_version": 2,
  "project_key": "stable-local-project-uuid",
  "project_name": "我的短剧",
  "script_revision": "v3-approved",
  "scenes": [
    {
      "scene_id": "SC01",
      "asset_version": "v1",
      "model": "runninghub-video:minimax-h3-ref2va-advanced",
      "prompt": "已经确认的镜头提示词",
      "script": "对应脚本",
      "images": ["owned-upload-id"],
      "videos": [],
      "audios": [],
      "ratio": "16:9",
      "quality": "768P",
      "duration": 10
    }
  ]
}
```

每批 1–20 个任务，scene_id 批内唯一；新画布上限 200 节点，已有画布检查节点/连线上限。asset_version 为记录字段，不代表人工已验收。

v2 默认复用同一作品画布：优先显式 canvas_key，其次由稳定 project_key 生成，没有 project_key 时按 project_name。建议技能第一次创建本地项目时保存 UUID，后续所有阶段沿用。用户要新画布时换 project_key。每个会员独立查找映射，相同 key 不会跨会员共享。旧版不带 workflow_version/project_key 的请求仍保留原 canvas_key 行为。

生成图片使用 `parameters:{"size":"auto"}`。配乐例如 `parameters:{"isInstrumental":true,"format":"mp3"}`。配音例如 `parameters:{"audio_config":{"format":"mp3","speech_rate":0}}`。这些任务不填写视频 quality/duration；不认识的 parameters 或 scene 字段直接拒绝。

后处理：`reviewed:true,source_task_id:"本人已成功视频任务ID"`，单独报价；不重复传参考数组。普通超分、深度、字幕擦除也可用 `reviewed:true,videos:["本人上传视频素材ID"]`；两种来源不能混用。H3 2K 必须用原 H3 任务，固定 2K，不能另填 duration。

### 报价响应（数值为结构示例）

```json
{
  "quote_id": "quote-uuid",
  "project_name": "我的短剧",
  "script_revision": "v3-approved",
  "canvas_key": "canvas-mapping-uuid",
  "expires_at": 1790000000000,
  "estimated_points": 23.4,
  "confirmation_required": true,
  "items": [{
    "scene_id": "SC01",
    "model": "runninghub-video:minimax-h3-ref2va-advanced",
    "stage": "generate",
    "estimated_points": 23.4,
    "duration": 10,
    "quality": "768P",
    "pricing_revision": "sha256-of-pricing-configuration",
    "effective_parameters": {"ratio":"16:9","duration":10,"quality":"768P"},
    "reference_counts": {"images":1,"videos":0,"audios":0}
  }]
}
```

报价有效期 30 分钟。effective_parameters 表示传给现有平台生成服务的参数；原服务中“跟随首帧/原视频”的比例规则仍然优先。技能必须展示任务清单、参数和预估总额；不得自行调用下一步。服务会在提交和排队执行前再次核对价格/模型/素材变化。

### 确认后提交

```json
{"quote_id":"quote-uuid","confirmed":true,"accepted_estimated_points":23.4}
```

同一 quote_id 并发确认或网络重试返回同一个 run_id，不再次执行。幂等范围是会员+quote_id；新报价代表新一次生产意图。因此技能须先保存报价和提交结果，提交超时后重试原 quote_id，不能重新报价再自动提交。每会员最多 5 个活动批次，模型队列继续使用原并发配置。

### 查询与结果

```json
{
  "run_id":"run-uuid","quote_id":"quote-uuid",
  "status":"succeeded","estimated_points":23.4,
  "settled_points":23.4,"known_settled_points":23.4,"settlement_status":"settled",
  "canvas":{"project_id":"project-uuid","canvas_key":"mapping-uuid","url":"/canvas.html?project=project-uuid","sync_status":"synced","error":""},
  "items":[{
    "scene_id":"SC01","task_id":"memberapi-task-uuid","node_id":"node-uuid",
    "kind":"video","stage":"generate","status":"success",
    "estimated_points":23.4,"actual_points_cost":23.4,"settlement_status":"settled",
    "billing_task_id":"memberapi-task-uuid","pricing_revision":"sha256",
    "images":[],"videos":["https://media.example/owned-result.mp4"],"audios":[],
    "materials":[{"id":"result:memberapi-task-uuid:videos:0","media_type":"video","url":"https://media.example/owned-result.mp4","download_url":"/api/v1/production/tasks/memberapi-task-uuid/results/videos/0"}],
    "output":{"duration":10,"original_duration":null,"quality":"768P","format":null},
    "asset_version":"v1","source_task_id":null,"error":"","error_code":null
  }]
}
```

run.status：processing / succeeded / needs_attention。item.status：queued / running / success / failed / unknown。

actual_points_cost 为 `number|null`。settlement_status：not_settled / reserved / pending_verification / settled / refunded。查询可附带 settlement：reservation_id、status（原账本状态）、reserved_points、updated_at。退款且任务明确失败时实际消耗可为 0；状态不确定时即使预冻结已释放，也继续为 null，等待核实。

settled_points 仅当全部任务金额已知时为数字，否则 null；known_settled_points 只是已知部分的小计，不能当总成本。platform_points_left 是服务实际返回时的余额快照，不是永远实时余额。声音实际结算可低于预冻结额；视频保持原服务实际输出时长结算规则，预估不是擅自改变原计费规则的硬上限。

### 错误结构

```json
{"error":"报价已过期，请重新估价确认。","code":"quote_expired"}
```

| HTTP / code | 技能处理 |
| --- | --- |
| 400 invalid_request / invalid_parameters / unsupported_model | 修改参数或选择兼容模型，再报价 |
| 401 / 403 | 停止提交，提示密钥、账号、会员权限问题 |
| 402 insufficient_points | 展示原报价，补足余额后重试；不换模型自动生成 |
| 404 | 不存在或不属于当前会员，不尝试其他会员资源 |
| 409 confirmation_required / review_required | 等会员明确确认费用或验收原片 |
| 409 quote_expired / quote_changed | 重新报价并让用户确认变更 |
| 409 result_not_ready | 查询原任务，不能重新生成 |
| 429 | 等现有批次完成后重试原报价 |
| 500/502 或网络中断 | 保存请求/报价/任务 ID；查询、重试同一确认，不创建新生产意图 |

部分历史上传/会员权限中间件只返回 error，code 可能缺失。生成失败详情也见 item.error / error_code。

## 4. 可靠性与现有工作流兼容

- 原 H3 多模态、首尾帧、普通超分、H3 2K 保留原计费函数与生成服务。报价、run、canvas 旧路径仍有效，现有 Python 技能客户端回归通过。
- 原 `videos` 字段保留，新增 images/audios/materials/output 等。旧客户端若把批次 settled_points 强制当数字，需要改成允许 null；本仓库旧技能不依赖这个字段做运算。
- 图片额外使用现有积分冻结/结算函数，原网页图片扣分路径不改。生成成功的文件先保存，再结算；结算失败只重试结算。
- 音乐/配音使用原服务持久化任务和确定性请求 ID；进程恢复查询原任务，不能重新发送不确定请求。
- RunningHub/H3 有已保存上游编号时可恢复；其他视频通道现有服务未提供统一持久化恢复钩子，进程在提交后中断且无回执时标 unknown，不会盲目重发。图片提交/转存不确定也需要人工核对。接口不把这种情况伪装成“失败可免费重试”。
- API 查询和下载不调用生成服务。画布同步失败保留成功媒体、费用及任务，后台可重试挂接；同步不触发扣分。音频历史保存在原音频任务服务及生产批次，不写入图片历史。
- 输入和输出关联画布节点、task_id、source_task_id，已有参考 URL 复用节点。资产/脚本人工验收和“最终采用版本”由技能保存，平台不自动把最新生成标为采用。
- 不包含剪映草稿、字幕编辑、本地剪辑、声音替换或独立音效服务。

## 5. 技能包实际对接

1. 每个本地项目生成并保存 project_key；每个会员在本机环境变量中配置自己的 Key。插件/技能分发包不包含 Key、会员数据或供应商地址。
2. 读取 models，只从已适配目录选兼容模型，显示限制；不能把 unavailable 或 native_audio=null 解释为已支持。
3. 维护 `本地资产编号/版本/哈希 → 平台素材 ID`，只上传新资产。已生成图片结果的素材 ID 直接用于分镜和视频。
4. 图片资产、分镜、视频、可选声音分别组批 quote，保存完整报价清单。用户确认该清单后才能 submit；同一报价重试复用 quote_id。
5. 每 5–10 秒 status 查询原 run；把 estimated_points、actual_points_cost、settlement_status 分开存。unknown 停止自动重生；下载绝不新建任务。
6. 下载选定成功结果到本地，成员验收后记录 adopted=true。超分另建 reviewed:true 的报价，沿用 project_key，并以 source_task_id 关联原片。
7. 最终剪辑只导入会员已采用的版本；本地技能自行制作字幕、剪映草稿和成片。

使用包内现有 [scripts/production.py](../scripts/production.py)，完整的本地清单、路径约定与命令见 [全流程调用说明](fullflow.md)。该客户端仅依赖 Python 标准库，不需要另一套示例客户端。

下面是本地客户端清单示例。将 JSON 保存到**自己的项目根目录**，命名为 `production-v2.json`；这是由会员创建的输入文件，不是包内附件。先查询实时目录，核实示例模型的权限和参数，再改成已确认的内容：

```json
{
  "project_name": "我的作品",
  "script_revision": "v1",
  "scenes": [
    {
      "scene_id": "CHAR01",
      "model": "grok------api:gpt-image-2.5-flare",
      "prompt": "白色背景的蓝色陶瓷茶杯产品资产图，无文字",
      "parameters": {"size": "1024x1024"}
    }
  ]
}
```

PowerShell 示例中，先把两个目录改成实际路径；`QUOTE_ID` / `RUN_ID` 替换为本次接口返回的真实编号，不可原样提交。`--project` 放在子命令之前。

```powershell
$skillDir = 'C:\Users\你的用户名\.agents\skills\lingchuang-video'
$projectDir = 'D:\我的影视项目'
python "$skillDir/scripts/production.py" --project "$projectDir" models
python "$skillDir/scripts/production.py" --project "$projectDir" quote production-v2.json
# 展示逐项报价和总额，取得会员对本次有效报价的明确确认后才执行下一行：
python "$skillDir/scripts/production.py" --project "$projectDir" submit QUOTE_ID --confirm QUOTE_ID
python "$skillDir/scripts/production.py" --project "$projectDir" status RUN_ID
python "$skillDir/scripts/production.py" --project "$projectDir" download RUN_ID
```

客户端会在 `quote` 时上传清单引用的本地素材，无需单独的上传子命令。本地 `images/videos/audios` 是项目内文件路径，已有素材用 `images_asset_ids/videos_asset_ids/audios_asset_ids`；客户端转换为上文 HTTP 请求所需的素材 ID，不能直接把 HTTP 示例当成本地清单。

报价保存到项目 `.lczyai/fullflow/quotes/<quote_id>.json`，批次记录保存到 `.lczyai/fullflow/runs/<run_id>.json`。`submit` 从已保存报价读取确认金额，并要求 `--confirm` 与同一个报价 ID 一致；没有额外的输出文件或手填金额参数。`download RUN_ID` 下载该批次成功项的图片、视频和音频到 `outputs/<run_id>/`，下载请求不向媒体域名携带会员 Key，已有目标文件不覆盖。未提交的过期报价使用 `requote QUOTE_ID` 刷新，展示新报价后重新确认。

## 6. v0.4.0 验证边界

核心测试覆盖会员接口与新旧客户端、素材归属、显式费用确认、并发重复提交、余额不足、混合任务及跨入口复用画布、结果再引用、结算恢复、声音服务竞态、标准线路报价与历史规则兼容。供应商为模拟对象，未执行付费生成。网站另通过图片缩放、视频弹窗、后台下载、直连下载及模型分类的浏览器测试。

发布前构建和语法检查通过；发布后核对实时目录、鉴权、免费报价。适配不代表所有供应商都完成过真实付费验收，付费测试仍要另行确认。独立音效、SD 参考视频附加成本等未核实能力保持关闭。

## v0.4.0 补充

nsdd 与此入口双向复用 canvas_key；首次作品请串行提交首批，获得 project_id 后跨入口追加。两种入口都接受本人已成功结果的 result:task:kind:index 素材引用。POST /api/v1/production/quotes/:id/refresh 仅刷新未提交报价，旧报价失效；已提交报价返回 409。标准 nsdd 视频新报价按实际所用线路的常规价格结算（standard_route），保留历史报价规则；图片固定价格不变。缺失线路或超出上限不自动扣补差，进入 reconciliation。平台内部路线仍由供应商 Key 策略决定，未实现强制最低线路。
