# nsdd 图片和视频生产（会员 API）

使用包内 [scripts/nsdd.py](../scripts/nsdd.py)，Python 3.10+ 无第三方依赖。会员 Key 沿用 LCZYAI_API_KEY，仅发送给 https://chat.lczyai.com。禁止直接使用供应商 Key。页面名称后缀为 `· nsdd`；为兼容任务追踪，协议模型 ID 保留 `linhai:`，参数名保留 `linhaiParams`。

## 已接入

| 显示名称（均带 nsdd 后缀） | 协议模型 ID |
|---|---|
| SD 2.5 满血版 按秒 | linhai:seedance-2.5-guanfang-anmiao |
| SD 2.5 全能参考 按秒 | linhai:seedance-2.5-anmiao-quannengcankao |
| MiniMax H3 | linhai:minimax-h3 |
| 海螺 H3 参考生 | linhai:hailuo-h3-cankaosheng |
| 海螺 H3 文生视频 | linhai:hailuo-h3 |
| 海螺 H3 全能参考 | linhai:hailuo-h3-quannengcankao |
| GK-video-3 | linhai:gk-video-3 |
| GK-video-3.5 | linhai:gk-video-3.5 |
| 视频超分 | linhai:video-enhance |
| TT Image 2.5 | linhai:tt-image-2.5 |

先运行 `python <技能路径>/scripts/nsdd.py --project <本地项目> models`，以实时返回的启用模型、参数和素材限制为准。不能从名字推断支持分辨率、参考音频、首尾帧或时长。

限制：SD 的参考视频计费待核实，暂不支持视频参考及延长；TT 尚未接电商批量通道。nsdd H3 不等同于旧 RH H3，不能自动接旧 H3 专用 2K 再生成；验收后可另报价使用 nsdd 视频超分。配音、配乐通过 [全流程客户端](fullflow.md)；独立音效未适配。参考音频不等于配音功能。

## 清单、报价、执行

下例须按实际项目修改并保存为项目根目录的 `scene.json`；`prompts/SC01.txt` 与 `assets/character.png` 是用户提供的项目文件，不是包内附件。下文短命令均加 `python <技能路径>/scripts/nsdd.py --project <本地项目>` 前缀；尖括号全部替换，含空格路径加引号，`--project` 放在子命令之前。

每份 JSON 一个镜头/资产任务，保留文件名/镜头编号，多镜分份准备，逐项确认预扣。示例（素材路径均相对项目根目录）：

```json
{
  "project_name": "我的作品",
  "scene_id": "SC01",
  "script_revision": "v1",
  "model": "linhai:minimax-h3",
  "prompt_file": "prompts/SC01.txt",
  "images": ["assets/character.png"],
  "videos": [],
  "audios": [],
  "duration": 6,
  "quality": "768P",
  "ratio": "16:9",
  "generationType": "REFERENCE"
}
```

图片任务可用 `linhai:tt-image-2.5`，省略视频 duration/quality，使用 `resolution:"auto"`、`ratio:"auto"`。无需默认 4K。高级参数按目录放到 `linhaiParams`，例如超分 `fps/tool_version/scene/enhance_style`。

1. `quote scene.json` 上传素材并报价，不生成、不预扣。每文件上传最多120MB，模型限制可能更小；不可为了通过限制擅自压缩素材。`images_asset_ids/videos_asset_ids/audios_asset_ids` 可引用本会员已有素材，不重复上传。
2. 展示名称、镜头、清晰度/时长、minPoints–maxPoints、**reservedPoints（本次预扣上限）**、到期时间；TT 固定2积分。等待会员明确确认该清单后执行 `submit <报价id> --confirm <同一id>`。不能只让会员确认较低的 minPoints。
3. 报价有效60秒；过期用 `requote <旧报价id>`，展示新报价并重新确认。脚本和服务端都会拒绝对已提交或待核对的报价刷新，避免丢响应后重复生成。不要擅自删除 `.lczyai/nsdd/` 缓存。
4. `status <taskId>` 查询原任务；`unknown`/reconciliation 停止重做。新报价完成后按实际所用线路对应的常规价格结算并退差额，历史报价仍按原规则；actualPoints:null 是未结算，不是0。查询和下载不扣生成积分。
5. `download <taskId>` 把原结果保存到 `outputs/<taskId>/`；下载不附带会员凭证。返回结果、积分和画布链接，完成后仍需验收。

同项目复用 `.lczyai/canvas.json` 和上传摘要缓存，nsdd 与全流程入口可双向接续已有画布；先完成首批提交取得画布编号，再跨入口追加。result:... 和本站素材 ID 均可引用；不要同时从两个入口首次建画布。单画布 200 节点/500 连线上限。

后处理需要会员验收后新建单独清单：`model:"linhai:video-enhance"`、`reviewed:true`、`videos_asset_ids:[<status 返回 materials 中的视频ID>]`、目标 quality；保留同项目绑定。重新报价和确认，绝不随首次生成自动执行。

## 接口格式

所有 API 仅接受 `Authorization: Bearer <会员Key>`。以下为无密钥格式，不是真实费用：

- GET `/api/v1/linhai/models` → `{models:[{id,name,kind,ratios,qualities,durations,images,videos,audios,firstLast,processing,parameters,pricing,limitations}]}`。
- POST `/api/v1/linhai/materials/uploads`：multipart `files`，每次至多3个 → `{materials:[{id,url,mediaType}]}`。
- POST `/api/v1/linhai/quotes`：上述清单转换为素材ID数组，加 `canvas_key`；不传本地路径 → `{id,model,label,expiresAt,minPoints,maxPoints,reservedPoints,billingBasis,strategy,confirmation_required:true}`。
- POST `/api/v1/linhai/quotes/:id/refresh`：仅未提交报价可刷新。
- POST `/api/v1/linhai/tasks`：`{quoteId:"QUOTE_ID",confirmed:true,acceptedPoints:报价reservedPoints}` → 同一报价始终同一taskId。
- GET `/api/v1/linhai/tasks/:id` → `{taskId,status,result,estimatedPoints,maximumEstimatedPoints,reservedPoints,actualPoints,settlementStatus,error,materials,canvas}`。
- result成功含 images或videos、pointsCost、pointsLeft；canvas含 project_id、canvas_key、url、sync_status、error。结果素材materials含 id/url/mediaType，可用于后处理。
- status：queued/running/success/failed/unknown；settlementStatus：pending/reserved/settled/refunded/not_charged/reconciliation。失败不必然退款，保留状态原意。
- 错误 `{error:"说明"}`；400参数、401密钥、402积分不足、403权限、404归属/不存在、409报价失效/待核对、502处理暂不可用。

旧 `/api/v1/production/*` 和 `lczyai.py` 保持原协议；nsdd 本次使用单独入口，不能将新模型塞进旧入口提交。
