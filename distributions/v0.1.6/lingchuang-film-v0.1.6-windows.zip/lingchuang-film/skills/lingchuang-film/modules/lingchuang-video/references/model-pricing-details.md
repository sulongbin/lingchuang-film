# 积分查询

旧静态价目表已经停用，避免误用过期的时段价格。套餐见 [三档方案](model-catalog.md)，所有提交以服务端当前报价为准。

图片现行：基础 Image 2 为 1 积分，Image 2.5 为 2 积分，Nano Banana Pro 为 3 积分。视频和后处理先展示规格、逐项预估及预扣上限，确认后提交。Veo 读取按清晰度区分的后台矩阵。未结算的实际积分为 null。

费用追溯：保存 quote_id、run_id/task_id、pricing_revision（如有）、estimated_points/minPoints/maxPoints、reservedPoints、actual_points_cost/actualPoints、settlement_status/settlementStatus。历史报价不按新规则重算；未确认的新费用不执行。
