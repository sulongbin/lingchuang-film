"""nsdd member API client; stdlib, never calls the supplier directly."""
import argparse
import json
import mimetypes
import os
import re
from pathlib import Path
import sys
import urllib.parse
import uuid
from lczyai import Client, load, save, sha

class NsddClient(Client):
    upload_endpoint = "/api/v1/linhai/materials/uploads"
    def models(self):
        return self.api("GET", "/api/v1/linhai/models")

    def upload(self, relative):
        file = self.local(relative)
        mime = mimetypes.guess_type(file.name)[0] or ""
        if not mime.startswith(("image/", "video/", "audio/")):
            raise ValueError("仅支持图片、视频和音频。")
        if file.stat().st_size > 120 * 1024 * 1024:
            raise ValueError("本地上传每文件最多 120MB；请勿擅自压缩原素材。")
        content = file.read_bytes()
        cache_path = self.folder / "uploads.json"
        cache = load(cache_path) if cache_path.exists() else {}
        key = sha(content) + ":" + mime
        if key in cache:
            return cache[key]
        boundary = "lczyai-" + uuid.uuid4().hex
        filename = sha(content)[:16] + file.suffix.lower()
        body = (f'--{boundary}\r\nContent-Disposition: form-data; name="files"; filename="{filename}"\r\nContent-Type: {mime}\r\n\r\n').encode() + content + f"\r\n--{boundary}--\r\n".encode()
        result = self.api("POST", self.upload_endpoint, body, "multipart/form-data; boundary=" + boundary)
        cache[key] = result["materials"][0]["id"]
        save(cache_path, cache)
        return cache[key]

    def quote(self, manifest):
        spec = load(self.local(manifest))
        models = {m["id"]: m for m in self.models()["models"]}
        model = models.get(spec.get("model"))
        if not model:
            raise ValueError("模型尚未适配或已停用，请查询 models。")
        if model["processing"] and spec.get("reviewed") is not True:
            raise ValueError("请先验收原视频；确认后在处理清单标记 reviewed:true。")
        files = [f for kind in ("images", "videos", "audios") for f in spec.get(kind, [])]
        fingerprints = [{"path": f, "sha256": sha(self.local(f).read_bytes())} for f in files]
        prompt = self.local(spec["prompt_file"]).read_text(encoding="utf-8-sig") if spec.get("prompt_file") else spec.get("prompt", "")
        fingerprint = sha(json.dumps({"spec": spec, "files": fingerprints, "prompt": prompt}, ensure_ascii=False, sort_keys=True).encode())
        index = self.folder / "nsdd/plans" / (fingerprint + ".json")
        if index.exists():
            return load(index)["quote"]
        for kind in ("images", "videos", "audios"):
            if len(spec.get(kind, [])) + len(spec.get(kind + "_asset_ids", [])) > model[kind]:
                raise ValueError("参考素材数量超过模型限制，不能自动丢弃素材。")
        request = {k: spec[k] for k in ("model", "project_name", "scene_id", "script_revision", "duration", "quality", "ratio", "resolution", "size", "generationType", "linhaiParams") if k in spec}
        request.update(prompt=prompt, canvas_key=self.canvas_key())
        for kind in ("images", "videos", "audios"):
            request[kind] = [self.upload(f) for f in spec.get(kind, [])] + spec.get(kind + "_asset_ids", [])
        quote = self.api("POST", "/api/v1/linhai/quotes", request)
        doc = {"quote": quote, "request": request, "fingerprint": fingerprint}
        save(self.folder / "nsdd/quotes" / (quote["id"] + ".json"), doc)
        save(index, doc)
        return quote

    def submit(self, quote_id, confirmation):
        self.identifier(quote_id)
        if confirmation != quote_id:
            raise ValueError("必须确认同一份报价。")
        doc = load(self.folder / "nsdd/quotes" / (quote_id + ".json"))
        q = doc["quote"]
        result = self.api("POST", "/api/v1/linhai/tasks", {"quoteId": quote_id, "confirmed": True, "acceptedPoints": q["reservedPoints"]})
        doc["task_id"] = result["taskId"]
        save(self.folder / "nsdd/quotes" / (quote_id + ".json"), doc)
        save(self.folder / "nsdd/tasks" / (result["taskId"] + ".json"), result)
        return result

    def status(self, task_id):
        if not re.fullmatch(r"linhai-[a-f0-9]{64}", task_id):
            raise ValueError("任务编号无效。")
        result = self.api("GET", "/api/v1/linhai/tasks/" + task_id)
        save(self.folder / "nsdd/tasks" / (task_id + ".json"), result)
        return result

    def requote(self, quote_id):
        self.identifier(quote_id)
        doc = load(self.folder / "nsdd/quotes" / (quote_id + ".json"))
        if doc.get("task_id"):
            raise ValueError("原报价已提交，请查询原任务。")
        # Server checks whether this quote was submitted, including a lost submit response.
        quote = self.api("POST", "/api/v1/linhai/quotes/" + quote_id + "/refresh", {})
        doc["quote"] = quote
        save(self.folder / "nsdd/quotes" / (quote["id"] + ".json"), doc)
        save(self.folder / "nsdd/plans" / (doc["fingerprint"] + ".json"), doc)
        return quote

    def recover_quote(self, quote_id):
        # This API has no quote read endpoint. Refresh is the server-side atomic
        # verification: it rejects ANY persisted submit intent, even without taskId.
        # A rejection/timeout is not evidence of non-submission.
        return {"quote": self.requote(quote_id), "verification": "server_atomic_refresh"}

    def download(self, task_id):
        task = self.status(task_id)
        if task["status"] != "success":
            raise ValueError("任务尚未成功，请保留原编号查询。")
        result = task.get("result") or {}
        outputs = []
        for kind in ("images", "videos"):
            for i, url in enumerate(result.get(kind, [])):
                parsed = urllib.parse.urlparse(url)
                if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
                    raise ValueError("结果地址不安全。")
                suffix = Path(parsed.path).suffix.lower()
                allowed = (".mp4", ".webm", ".mov") if kind == "videos" else (".png", ".jpg", ".jpeg", ".webp")
                if suffix not in allowed:
                    suffix = ".mp4" if kind == "videos" else ".png"
                target = self.root / "outputs" / task_id / f"{kind}_{i+1}{suffix}"
                target.parent.mkdir(parents=True, exist_ok=True)
                if not target.exists():
                    temp = target.with_suffix(".part")
                    # The media request never carries a member or supplier key.
                    with self.opener.open(url, timeout=120) as response, temp.open("wb") as output:
                        while chunk := response.read(1024 * 1024):
                            output.write(chunk)
                    temp.replace(target)
                outputs.append(str(target))
        return {"files": outputs, "actualPoints": task.get("actualPoints"), "settlementStatus": task.get("settlementStatus"), "canvas": task["canvas"]}

def main():
    parser = argparse.ArgumentParser(description="nsdd：报价、预扣确认、异步查询、下载")
    parser.add_argument("--project", required=True)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("models")
    p = sub.add_parser("quote");p.add_argument("manifest")
    p = sub.add_parser("submit");p.add_argument("quote_id");p.add_argument("--confirm", required=True)
    p = sub.add_parser("requote");p.add_argument("quote_id")
    for cmd in ("status", "download"):
        p = sub.add_parser(cmd);p.add_argument("task_id")
    args = parser.parse_args()
    try:
        client = NsddClient(args.project)
        if args.command == "models": result = client.models()
        elif args.command == "quote": result = client.quote(args.manifest)
        elif args.command == "submit": result = client.submit(args.quote_id, args.confirm)
        elif args.command == "requote": result = client.requote(args.quote_id)
        else: result = getattr(client, args.command)(args.task_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, KeyError) as e:
        secret = os.environ.get("LCZYAI_API_KEY", "")
        print("失败：" + (str(e).replace(secret, "[已隐藏]") if secret else str(e)), file=sys.stderr)
        return 1

if __name__ == "__main__":
    sys.exit(main())
