"""Full-flow member client; retains legacy project binding and upload cache."""
import argparse
import json
import os
from pathlib import Path
import sys
import urllib.parse
from lczyai import Client, load, save, sha
from nsdd import NsddClient


class ProductionClient(NsddClient):
    upload_endpoint = "/api/v1/materials/uploads"

    def models(self):
        return self.api("GET", "/api/v1/models")

    def quote(self, manifest):
        spec = load(self.local(manifest))
        scenes = spec.get("scenes", [])
        if not scenes:
            raise ValueError("清单缺少 scenes。")
        available = {m["id"] for m in self.models()["models"]}
        fingerprints = []
        prepared = []
        for row in scenes:
            if row.get("model") not in available:
                raise ValueError("模型未适配、无权限或已停用；请先查询 models。")
            row = dict(row)
            if row.get("prompt_file"):
                row["prompt"] = self.local(row.pop("prompt_file")).read_text(encoding="utf-8-sig")
            for kind in ("images", "videos", "audios"):
                for name in row.get(kind, []):
                    fingerprints.append({"path": name, "sha256": sha(self.local(name).read_bytes())})
            prepared.append(row)
        fingerprint = sha(json.dumps({"spec": spec, "scenes": prepared, "files": fingerprints}, ensure_ascii=False, sort_keys=True).encode())
        index = self.folder / "fullflow/plans" / (fingerprint + ".json")
        if index.exists():
            return load(index)["quote"]
        for row in prepared:
            for kind in ("images", "videos", "audios"):
                row[kind] = [self.upload(f) for f in row.get(kind, [])] + row.pop(kind + "_asset_ids", [])
        request = {k: spec[k] for k in ("project_name", "script_revision") if k in spec}
        request.update(workflow_version=2, canvas_key=self.canvas_key(), scenes=prepared)
        quote = self.api("POST", "/api/v1/production/quotes", request)
        doc = {"quote": quote, "request": request, "fingerprint": fingerprint}
        save(self.folder / "fullflow/quotes" / (quote["quote_id"] + ".json"), doc)
        save(index, doc)
        return quote

    def submit(self, quote_id, confirmation):
        self.identifier(quote_id)
        if confirmation != quote_id:
            raise ValueError("必须确认同一份报价。")
        doc = load(self.folder / "fullflow/quotes" / (quote_id + ".json"))
        result = self.api("POST", "/api/v1/production/runs", {"quote_id": quote_id, "confirmed": True, "accepted_estimated_points": doc["quote"]["estimated_points"]})
        doc["run_id"] = result["run_id"]
        save(self.folder / "fullflow/quotes" / (quote_id + ".json"), doc)
        save(self.folder / "fullflow/runs" / (result["run_id"] + ".json"), result)
        return result

    def requote(self, quote_id):
        self.identifier(quote_id)
        doc = load(self.folder / "fullflow/quotes" / (quote_id + ".json"))
        if doc.get("run_id"):
            raise ValueError("原报价已提交，请查询原任务。")
        quote = self.api("POST", "/api/v1/production/quotes/" + quote_id + "/refresh", {})
        doc["quote"] = quote
        save(self.folder / "fullflow/quotes" / (quote["quote_id"] + ".json"), doc)
        save(self.folder / "fullflow/plans" / (doc["fingerprint"] + ".json"), doc)
        return quote

    def recover_quote(self, quote_id):
        return Client.recover_quote(self, quote_id)

    def status(self, run_id):
        self.identifier(run_id)
        result = self.api("GET", "/api/v1/production/runs/" + run_id)
        save(self.folder / "fullflow/runs" / (run_id + ".json"), result)
        return result

    def download(self, run_id):
        run = self.status(run_id)
        files = []
        for item in run["items"]:
            if item["status"] != "success":
                continue
            for kind in ("images", "videos", "audios"):
                for i, url in enumerate(item.get(kind, [])):
                    parsed = urllib.parse.urlparse(url)
                    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
                        raise ValueError("结果地址不安全。")
                    suffix = Path(parsed.path).suffix.lower()
                    if suffix not in (".png", ".jpg", ".jpeg", ".webp", ".mp4", ".webm", ".mov", ".wav", ".mp3", ".ogg", ".pcm"):
                        suffix = {"images": ".png", "videos": ".mp4", "audios": ".mp3"}[kind]
                    # Do not trust scene names as paths. Task IDs are assigned by the server.
                    task_id = item["task_id"]
                    if not all(c.isalnum() or c == "-" for c in task_id):
                        raise ValueError("任务编号无效。")
                    target = self.root / "outputs" / run_id / f"{task_id}_{kind}_{i+1}{suffix}"
                    target.parent.mkdir(parents=True, exist_ok=True)
                    if not target.exists():
                        temp = target.with_suffix(".part")
                        with self.opener.open(url, timeout=180) as response, temp.open("wb") as output:
                            while chunk := response.read(1024 * 1024):
                                output.write(chunk)
                        temp.replace(target)
                    files.append(str(target))
        return {"files": files, "status": run["status"], "settled_points": run["settled_points"], "settlement_status": run["settlement_status"], "canvas": run["canvas"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("models")
    sub.add_parser("quote").add_argument("manifest")
    p = sub.add_parser("submit"); p.add_argument("quote_id"); p.add_argument("--confirm", required=True)
    sub.add_parser("requote").add_argument("quote_id")
    for name in ("status", "download"):
        sub.add_parser(name).add_argument("run_id")
    args = parser.parse_args()
    try:
        client = ProductionClient(args.project)
        if args.command == "models": result = client.models()
        elif args.command == "quote": result = client.quote(args.manifest)
        elif args.command == "submit": result = client.submit(args.quote_id, args.confirm)
        elif args.command == "requote": result = client.requote(args.quote_id)
        else: result = getattr(client, args.command)(args.run_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, KeyError) as e:
        secret = os.environ.get("LCZYAI_API_KEY", "")
        print("失败：" + (str(e).replace(secret, "[已隐藏]") if secret else str(e)), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
