# 旧 H3 客户端本地生产清单

本页仅配合 [scripts/lczyai.py](../scripts/lczyai.py)。新图片、视频及声音生产见 [全流程调用](fullflow.md)，nsdd 见 [专用说明](nsdd.md)。

把下例修改后保存为项目根目录的 `production.json`；示例中的 `scripts/SC01.md`、`prompts/SC01.txt` 和 `assets/` 素材是会员自己的项目文件，不是技能包文件。命令中的尖括号需替换，含空格的路径加引号，`--project` 放在子命令之前。

示例 ID 对应当前平台 H3 模型；执行前通过 `models` 核实可用性和价格，不在 Skill 固定积分数值。

```json
{
  "project_name": "宣传片",
  "script_revision": "v1-confirmed",
  "workflow": {
    "generate": {
      "model": "runninghub-video:minimax-h3-ref2va-advanced",
      "ratio": "16:9",
      "duration": 15
    },
    "after_review": {
      "model": "runninghub-video:minimax-h3-regeneration-2k",
      "quality": "2K"
    }
  },
  "scenes": [
    {
      "scene_id": "SC01",
      "script_file": "scripts/SC01.md",
      "prompt_file": "prompts/SC01.txt",
      "images": ["assets/SB01.png", "assets/角色A.png"],
      "videos": []
    }
  ]
}
```

- 每批 1–20 个镜头，`scene_id` 唯一，只用英文字母、数字、下划线和连字符。大项目分批时使用不同项目名称或版本，并保留每批 run_id。
- 工作流生成参数为默认值，单个 scenes 条目可覆盖 model、duration、ratio、quality。清晰度省略时由 API 明确返回默认值供会员在报价中确认，不要求图片达到该分辨率。
- prompt_file/script_file 为 UTF-8 项目内相对路径，也可使用 prompt/script 字符串；文件存在时优先读取文件。保留原有分镜时序和资产职责，不直接拼接所有文本来制造提示词。
- images/videos 均为项目内本地路径。图片编号由数组顺序确定。H3 首尾帧使用 images[0] 为首帧、images[1] 为可选尾帧；H3 多模态的图片、视频、音频数量以 API 为准。
- audios 可填写本人平台已有音频素材 ID。本期 CLI 不上传本地音频。
- 每个镜头同时保存脚本、实际发送提示词及素材顺序；本期不上传整个项目目录。
- 同一本地项目默认共用 `.lczyai/canvas.json` 中的剧本画布编号；不同提交清单与不同片段名称不会再各建一张画布。另一个独立剧本使用独立项目目录。API 直连时在清单顶层传同一个 UUID 格式的 `canvas_key`，服务端按会员隔离该编号。
- 需要普通超分时，把 after_review.model 改为 models 中 stage=upscale 的真实模型 ID；未配置 after_review 就只做首次生成。

常用命令（所有命令前加 `python <技能目录>/scripts/lczyai.py --project <项目目录>`）：

| 命令 | 用途 |
| --- | --- |
| `models` | 查询模型、能力与计费配置 |
| `prepare production.json` | 校验本地清单、上传参考文件并获取本阶段报价 |
| `submit <quote_id> --confirm <quote_id>` | 在会员明确确认报价后提交，同一报价幂等 |
| `status <run_id>` | 查询原任务，保存本地状态 |
| `next-quote <run_id> --scenes SC01 SC03 --reviewed` | 验收后获取所选镜头的后续处理报价 |
| `requote <quote_id>` | 为尚未提交的清单刷新过期报价，仍需重新确认 |
| `download <run_id>` | 下载成功的镜头视频，不重新生成 |
| `join-canvas <run_id> --target-run <主画布run_id>` | 将已完成任务归入本人主画布，保留原画布，绑定后续生成；不调用模型、不扣分 |

不要并行运行同一项目的多个 prepare/submit 客户端；本地状态文件按单客户端操作设计。服务端会对同一报价的重复/并发提交去重。更换会员时使用独立项目目录，避免混用素材 ID。
