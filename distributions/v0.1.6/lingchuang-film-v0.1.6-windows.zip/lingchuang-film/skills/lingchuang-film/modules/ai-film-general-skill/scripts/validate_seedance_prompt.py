#!/usr/bin/env python3
"""Validate the universal four-section video prompt contract and granularity signals."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


ALLOWED_HEADINGS = ["素材描述", "一句话概括", "画面内容描述", "全局补充"]
VERSION = "1.2"
FORBIDDEN_HEADINGS = {
    "参考图说明",
    "参考视频与参考图说明",
    "生成任务",
    "前情提要",
    "固定空间关系",
    "光线与气氛",
    "摄影与质感",
    "声音",
    "禁止项",
}
FORBIDDEN_BLOCK_HEADINGS = {
    "SCENE CONTEXT",
    "ACTIVE REFERENCES",
    "LOCATION MAP",
    "FIRST FRAME AND SPATIAL BLOCKING",
    "FORMAT MODE",
    "OPTICS",
    "CAMERA",
    "ACTION TIMING",
    "PHYSICS",
    "LIGHTING",
    "AUDIO",
    "CHARACTER ACTING",
    "STYLE / QUALITY",
    "LOCAL FAILURE CONSTRAINTS",
}


def read_text(path: str) -> str:
    if path == "-":
        return sys.stdin.read()
    return Path(path).read_text(encoding="utf-8-sig")


def has_any(text: str, terms: list[str]) -> bool:
    return any(term in text for term in terms)


def split_shots(text: str) -> list[tuple[int, str]]:
    pattern = re.compile(r"(?m)^镜头\s*(\d+)\s*(?=[，,:：]|$)")
    matches = list(pattern.finditer(text))
    shots: list[tuple[int, str]] = []
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        shots.append((int(match.group(1)), text[match.start() : end]))
    return shots


def split_sections(text: str) -> dict[str, str]:
    pattern = re.compile(r"(?m)^【([^】\n]+)】\s*$")
    matches = list(pattern.finditer(text))
    sections: dict[str, str] = {}
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        sections[match.group(1)] = text[match.end() : end].strip()
    return sections


def visible_length(text: str) -> int:
    return len(re.sub(r"\s+", "", text))


def detect_profiles(text: str, requested: str) -> list[str]:
    if requested != "auto":
        return [requested]
    profiles: list[str] = []
    if has_any(text, ["对白", "口型", "听到", "说：", "说：“", "画外音"]):
        profiles.append("dialogue")
    if has_any(text, ["战斗", "攻击", "斩", "劈", "格挡", "闪避", "刀气", "受击", "命中"]):
        profiles.append("action")
    if has_any(text, ["法阵", "结界", "能量", "吐息", "龙火", "刀气", "特效"]):
        profiles.append("vfx")
    crowd_hits = sum(text.count(term) for term in ["群众", "村民", "人群", "虫群", "阵营"])
    if crowd_hits >= 3 or has_any(text, ["群体调度", "同一批群众", "同一批村民"]):
        profiles.append("crowd")
    return profiles or ["common"]


def main() -> int:
    parser = argparse.ArgumentParser(
        description="检查AI影视视频提示词的统一四段式、镜头编号、图号和颗粒度信号。"
    )
    parser.add_argument("path", help="UTF-8提示词文件；使用-从stdin读取")
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="当前界面的可见字符上限；不传则不设置长度上限，旧6000界面请显式传--limit 6000",
    )
    parser.add_argument(
        "--profile",
        choices=["auto", "common", "dialogue", "action", "vfx", "crowd"],
        default="auto",
        help="颗粒度检查类型，默认自动识别",
    )
    parser.add_argument(
        "--strict-warnings", action="store_true", help="存在颗粒度警告时返回非零状态"
    )
    parser.add_argument("--version", action="version", version=VERSION)
    args = parser.parse_args()

    text = read_text(args.path).replace("\r\n", "\n").lstrip("\ufeff")
    errors: list[str] = []
    warnings: list[str] = []

    headings = re.findall(r"(?m)^【([^】\n]+)】\s*$", text)
    if headings != ALLOWED_HEADINGS:
        errors.append(
            "一级标题必须且只能依次为："
            + "、".join(f"【{item}】" for item in ALLOWED_HEADINGS)
            + f"；当前识别为：{headings or '无'}"
        )
    legacy = [heading for heading in headings if heading in FORBIDDEN_HEADINGS]
    if legacy:
        errors.append("检测到旧一级标题：" + "、".join(legacy))

    english_blocks = [
        line.strip()
        for line in text.splitlines()
        if line.strip().upper() in FORBIDDEN_BLOCK_HEADINGS
    ]
    if english_blocks:
        errors.append(
            "检测到旧CINEDANCE英文章节；请把其语义映射进固定四段式："
            + "、".join(dict.fromkeys(english_blocks))
        )

    if re.search(r"(?m)^(?:R\d+[A-Z]?|F\d+|G\d+|C\d+|W\d+)\s*[，,:：]", text):
        errors.append("逐镜标题仍使用R/F/G/C/W制作编号；请改为镜头1、镜头2……")

    shots = split_shots(text)
    if not shots:
        warnings.append("未识别到“镜头1、镜头2……”；若不是单镜无标题任务，请补逐镜标题。")
    else:
        numbers = [number for number, _ in shots]
        expected = list(range(1, len(numbers) + 1))
        if numbers != expected:
            errors.append(f"镜头编号不连续：当前{numbers}，应为{expected}")

    numbering_styles = []
    if re.search(r"\bImage\s*\d+", text, flags=re.IGNORECASE):
        numbering_styles.append("Image 1")
    if re.search(r"图片\s*\d+", text):
        numbering_styles.append("图片1")
    if re.search(r"(?<!片)图\s*\d+", text):
        numbering_styles.append("图1")
    if re.search(r"(?<!片)图[一二三四五六七八九十]+", text):
        numbering_styles.append("图一")
    if len(numbering_styles) > 1:
        errors.append("图号体系混用：" + "、".join(numbering_styles))

    sections = split_sections(text)
    visible_count = visible_length(text)
    total_count = len(text)
    if args.limit is not None and visible_count > args.limit:
        errors.append(f"去空白可见字符{visible_count}，超过上限{args.limit}")

    section_counts = {name: visible_length(body) for name, body in sections.items()}
    content_count = section_counts.get("画面内容描述", 0)
    body_count = sum(section_counts.values())
    content_ratio = content_count / body_count if body_count else 0.0
    if body_count and content_ratio < 0.45:
        warnings.append(
            f"【画面内容描述】仅占四段正文{content_ratio:.1%}；复杂镜头通常应约占一半以上，"
            "请检查素材说明和全局规则是否挤占了表演、动作或特效过程。"
        )

    content_text = sections.get("画面内容描述", "")
    if content_text and not has_any(
        content_text,
        ["第一可见帧", "起始状态", "前情状态", "开头", "一开始", "已经"],
    ):
        warnings.append("【画面内容描述】未见第一可见帧或起始/前情状态。")

    if has_any(text, ["对白", "口型", "说：", "说：“"]):
        if not has_any(text, ["动作与表演", "身体反应", "表演："]):
            warnings.append("对白任务未清楚分配动作/表演语义。")
        if not has_any(text, ["对白与声音", "声音：", "对白："]):
            warnings.append("对白任务未清楚分配对白/声音语义。")

    for number, shot in shots:
        if "秒" not in shot[:180]:
            warnings.append(f"镜头{number}开头未见时长信息。")
        if not has_any(
            shot,
            ["景", "mm", "机位", "摄影机", "仰拍", "俯拍", "跟拍", "横移", "推进", "固定"],
        ):
            warnings.append(f"镜头{number}缺少可识别的景别/焦段/机位/运镜。")
        if not has_any(shot, ["画面", "前景", "中景", "后景", "背景", "左侧", "右侧", "世界", "站在"]):
            warnings.append(f"镜头{number}缺少人物或主体空间关系。")
        if not has_any(shot, ["结尾", "结束", "停在", "保持", "落到", "硬切", "为下一镜", "可剪"]):
            warnings.append(f"镜头{number}缺少明确终态或剪辑落点。")
        if visible_length(shot) < 180 and has_any(
            shot, ["对白", "说：", "说：“", "攻击", "命中", "法阵", "结界", "爆炸", "群众"]
        ):
            warnings.append(
                f"镜头{number}只有约{visible_length(shot)}个可见字符，"
                "对包含表演、动作、特效或群像的镜头可能不足。"
            )

    profile_text = (
        sections.get("一句话概括", "")
        + "\n"
        + sections.get("画面内容描述", text)
    )
    profiles = detect_profiles(profile_text, args.profile)
    if "dialogue" in profiles:
        dialogue_groups = {
            "目标/潜台词": ["想要", "想", "必须", "只想", "准备", "不忍"],
            "刺激": ["听到", "听见", "看见", "说到", "关键词", "称呼"],
            "眼线": ["眼线", "视线", "目光", "聚焦", "抬眼", "看向"],
            "面部/呼吸": ["眉", "眼睑", "嘴唇", "下颌", "呼吸", "吞咽"],
            "身体反应": ["肩", "重心", "手指", "抓", "脚步", "身体"],
            "口型归属": ["口型", "闭口", "嘴唇闭合", "不说话", "全程沉默"],
            "新状态": ["最终", "结尾", "落到", "转为", "意识到", "决定"],
        }
        missing = [name for name, terms in dialogue_groups.items() if not has_any(text, terms)]
        if missing:
            warnings.append("文戏颗粒度可能不足，缺少：" + "、".join(missing))

    if "action" in profiles:
        action_groups = {
            "意图/锁定": ["锁定", "判断", "目标", "攻击通道", "威胁"],
            "预备": ["蓄力", "承重", "重心", "回收", "蹬地", "压低"],
            "发力": ["发力", "腰髋", "肩背", "蹬地", "动力"],
            "轨迹": ["沿", "斜向", "横向", "由上", "由下", "弧线", "路径"],
            "接触": ["接触", "命中", "格挡", "擦过", "撞上", "咬住"],
            "形变": ["凹陷", "裂纹", "切开", "弯曲", "压缩", "熔裂", "折叠"],
            "反作用": ["反作用", "反震", "回弹", "滑出", "失衡", "踉跄", "顿挫"],
            "收势/结果": ["收势", "站稳", "落地", "结果", "重新", "停留", "稳定"],
        }
        present = [name for name, terms in action_groups.items() if has_any(text, terms)]
        if len(present) < 6:
            missing = [name for name in action_groups if name not in present]
            warnings.append(
                f"武戏动作链仅识别到{len(present)}/8项，建议补：" + "、".join(missing)
            )

    if "vfx" in profiles:
        vfx_groups = {
            "来源": ["从", "内部", "掌心", "刃口", "胸腔", "喉部", "香炉", "来源"],
            "前摇/形成": ["先", "汇聚", "聚集", "凝结", "形成", "由暗转亮", "逐渐"],
            "运动方向": ["沿", "向", "扩散", "下降", "喷出", "卷起", "流动"],
            "环境作用": ["照亮", "压低", "带动", "吹动", "冲击", "熔", "裂", "受光"],
            "终态": ["最终", "完成", "稳定", "消散", "结尾", "保持"],
        }
        missing = [name for name, terms in vfx_groups.items() if not has_any(text, terms)]
        if missing:
            warnings.append("特效阶段可能不完整，缺少：" + "、".join(missing))

    if "crowd" in profiles:
        crowd_groups = {
            "身份/人数": ["人数", "同一批", "村民", "群众", "虫群", "阵营"],
            "层次/占位": ["前景", "中景", "后景", "前排", "中排", "后排", "左侧", "右侧"],
            "错拍动作": ["错开", "不同步", "先后", "陆续", "有人", "分别"],
            "生命活动": ["呼吸", "重心", "衣袖", "擦泪", "叩拜", "爬行", "振翅"],
            "跨镜连续": ["同一批", "完全相同", "连续", "动作进度", "不换位", "不重置"],
        }
        missing = [name for name, terms in crowd_groups.items() if not has_any(text, terms)]
        if missing:
            warnings.append("群像颗粒度可能不足，缺少：" + "、".join(missing))

    limit_label = str(args.limit) if args.limit is not None else "未设置"
    print(f"字符：总计{total_count}；去空白可见字符{visible_count}；上限{limit_label}")
    if section_counts:
        print(
            "四段分配："
            + "；".join(f"{name}{count}" for name, count in section_counts.items())
            + f"；画面内容占比{content_ratio:.1%}"
        )
    print("识别配置：" + "、".join(profiles))
    print(f"镜头：{len(shots)}个")
    for message in errors:
        print("ERROR: " + message)
    for message in warnings:
        print("WARN: " + message)
    if not errors and not warnings:
        print("PASS: 统一四段式、编号、篇幅和颗粒度信号均通过。")
    elif not errors:
        print("PASS WITH WARNINGS: 格式通过；请人工复核颗粒度警告。")

    if errors or (warnings and args.strict_warnings):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
