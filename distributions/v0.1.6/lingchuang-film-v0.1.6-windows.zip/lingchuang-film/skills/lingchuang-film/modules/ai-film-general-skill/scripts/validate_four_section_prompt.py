#!/usr/bin/env python3
"""Compatibility-neutral entry point for the four-section video prompt validator."""

from validate_seedance_prompt import main


if __name__ == "__main__":
    raise SystemExit(main())
