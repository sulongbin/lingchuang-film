#!/usr/bin/env python3
"""Create a non-destructive AI film production project pack."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


VERSION = "1.3"

LONGFORM_ONLY = {
    "04_shots/sequence-register.md",
    "04_shots/change-impact.md",
}

MICRO_INCLUDE = {
    "00_project/project-brief.md",
    "00_project/input-readiness.md",
    "00_project/source-of-truth.md",
    "01_content/content-bible.md",
    "01_content/scene-breakdown.md",
    "02_bibles/character-bible.md",
    "02_bibles/look-bible.md",
    "03_assets/asset-register.md",
    "03_assets/asset-descriptors.md",
    "03_assets/asset-tests.md",
    "04_shots/shot-list.md",
    "04_shots/continuity-ledger.md",
    "05_prompts/image-prompt-log.md",
    "05_prompts/video-prompt-log.md",
    "05_prompts/generation-log.md",
    "06_reviews/review-log.md",
    "06_reviews/edit-needs.md",
}


def templates(title: str, profile: str) -> dict[str, str]:
    return {
        "00_project/project-brief.md": f"""# {title} 项目简报

- 项目ID：
- 项目文档版本：1.0（与skill版本独立）
- 形态：剧情 / 纪录片 / 广告 / MV / 实验 / 混合
- 媒介：真人 / 动画 / 风格化 / 混合
- 预期片长/集数：
- 规模档：{profile}
- 当前阶段：概念 / 内容 / 资产 / 镜头 / 生成 / 粗剪 / 接管
- 目标观众与核心体验：
- 本阶段完成定义：
- 目标真实度/视觉方向：
- 主要工具或待测试工具：
- 团队/工期/预算边界：
- 明确不做：

## 一句话内容

## 当前三项最高生产风险
""",
        "00_project/input-readiness.md": """# 输入完整度与下一步

| 层 | 已有 | 缺失 | 状态（已确认/待确认/工作假设） | 阻断哪一步 | 下一动作 |
|:---|:---|:---|:---|:---|:---|
| 内容/剧本 |  |  |  |  |  |
| 角色/出镜者 |  |  |  |  |  |
| 世界/品牌/地点 |  |  |  |  |  |
| 视觉/声音/表演 |  |  |  |  |  |
| 人物/场景/道具资产 |  |  |  |  |  |
| GEO/镜头/连续性 |  |  |  |  |  |
| 参考视频/尾态/返修源 |  |  |  |  |  |
""",
        "00_project/source-of-truth.md": """# 当前事实源

| 来源ID | 文件/链接 | 类型 | 版本/日期 | 覆盖范围 | 状态 | 当前真相 | 备注 |
|:---|:---|:---|:---|:---|:---|:---:|:---|
""",
        "00_project/decision-log.md": """# 导演决策日志

| 决策ID | 日期 | 决策 | 被替代内容 | 原因 | 影响资产/镜头/粗剪 | 决策人 | 状态 |
|:---|:---|:---|:---|:---|:---|:---|:---|
""",
        "01_content/content-bible.md": f"""# {title} 内容/故事圣经

> 剧情项目填写故事；纪录片改为研究问题和证据结构；广告改为传播任务和产品事实；MV改为音轨段落和视觉母题。不适用字段不要硬填。

## 核心命题/研究问题/传播目标

## 一句话故事/内容

## 主体、目标、阻力、代价与结局方向

## 关系/采访立场/品牌关系

## 世界规则或不可改事实

## 时间线/音乐段落

## 信息释放、伏笔与回收

## 当前待确认
""",
        "01_content/script-index.md": """# 剧本/内容源索引

| 内容ID | 类型 | 集/幕/段落 | 文件 | 版本 | 当前有效 | 缺失/冲突 |
|:---|:---|:---|:---|:---|:---:|:---|
""",
        "01_content/scene-breakdown.md": """# 场次/段落拆解

| 场次/段落ID | 地点/时间 | 功能 | 起始状态 | 结束状态 | 目标/信息/节拍 | 表演转折 | 动作/VFX | 资产 | 风险 |
|:---|:---|:---|:---|:---|:---|:---|:---|:---|:---|
""",
        "02_bibles/character-bible.md": """# 角色/出镜者圣经

## <角色ID> <角色名>

- 身份/年龄/体型：
- 稳定外观锚点：
- 关系与最高任务：
- 恐惧/秘密/矛盾：
- 能力、代价与禁区：
- 语言/Voice：
- 基础服装/道具：
- 状态资产：
- 跨镜不可漂移项：
""",
        "02_bibles/world-bible.md": """# 世界/品牌/地点规则

| 规则/地点ID | 定义 | 可见结果 | 能做 | 不能做 | 代价 | 相关场次 | 状态 |
|:---|:---|:---|:---|:---|:---|:---|:---|
""",
        "02_bibles/look-bible.md": """# 视觉圣经

| 场景/段落 | 真实度/媒介 | 时间/天气 | 主光世界方向 | 色彩/光比 | 材质 | 运动/颗粒 | VFX | 禁止漂移 |
|:---|:---|:---|:---|:---|:---|:---|:---|:---|
""",
        "02_bibles/sound-bible.md": """# 声音圣经

| 对象/角色 | 声音身份 | 语速/节奏 | 压力下变化 | 环境/空间 | 固定Voice文本 | 状态 |
|:---|:---|:---|:---|:---|:---|:---|
""",
        "02_bibles/acting-bible.md": """# 表演圣经

| 角色 | 身体传记/重心/步态 | 心理发动机 | 面具/破裂触发 | 习惯动作及触发 | 眼神/呼吸 | 地位行为 | 柔化对象 |
|:---|:---|:---|:---|:---|:---|:---|:---|
""",
        "03_assets/asset-register.md": """# 资产登记

| 资产ID | 类型 | 对象 | 基础/状态 | 参考文件 | 锁定职责 | 不继承 | descriptor版本 | 测试 | 适用镜头 | 状态 |
|:---|:---|:---|:---|:---|:---|:---|:---|:---|:---|:---|
""",
        "03_assets/asset-descriptors.md": """# 资产描述词

## <资产ID>

- 稳定descriptor：
- 当前状态descriptor：
- 参考图上传顺序与职责：
- 不得继承：
- 适用任务：人物/场景/道具/转真实/视频
- 已知失败：
""",
        "03_assets/asset-tests.md": """# 资产压力测试

| 测试ID | 资产ID | 角度/姿势/光线/同框条件 | 生成次数 | 可用结果 | 失败模式 | 修改 | 结论 |
|:---|:---|:---|:---:|:---|:---|:---|:---|
""",
        "04_shots/geo-maps.md": """# GEO空间图

## <场景ID>

- 世界方位：
- 地标与固定距离：
- 入口/出口：
- 人物/阵营常用区：
- 180度轴线：
- 摄影机允许侧：
- 主光世界方向：
- 环境声来源：
- 参考图及职责：
""",
        "04_shots/shot-list.md": """# 镜头表

| 镜头ID | 场次 | 观众必须读懂 | 时长/切点 | 起始/结束 | 景别/光学/机位 | 人物/空间 | 动作/表演 | 对白/声音 | 资产 | 路线 | 风险 |
|:---|:---|:---|:---|:---|:---|:---|:---|:---|:---|:---|:---|

路线：图片资产 / 视频直出 / 实拍迁移 / 视频续写 / 定点返修 / 覆盖补镜。
""",
        "04_shots/continuity-ledger.md": """# 连续性台账

| 镜头ID | 人物/服装/伤势 | 世界位置/朝向/眼线 | 动作进度 | 道具/VFX | 表演新状态 | 光/天气 | 声音 | 已完成/不得重演 | 下一镜 |
|:---|:---|:---|:---|:---|:---|:---|:---|:---|:---|
""",
        "04_shots/sequence-register.md": """# 序列与批次登记（longform）

| 序列/批次ID | 集/幕/段落 | 内容功能 | 镜头范围 | 核心资产/地点 | 依赖 | 当前锁定 | 负责人 | 风险 | 状态 |
|:---|:---|:---|:---|:---|:---|:---|:---|:---|:---|
""",
        "04_shots/change-impact.md": """# 变更影响登记（longform）

| 变更ID | 日期 | 变更 | 上游依据 | 受影响资产 | 受影响镜头/提示词 | 受影响粗剪/声音 | 动作 | 验证 | 状态 |
|:---|:---|:---|:---|:---|:---|:---|:---|:---|:---|
""",
        "05_prompts/image-prompt-log.md": """# 图像提示词日志

| 资产/图像ID | 任务类型 | Prompt版本 | 主案例 | 参考职责 | 唯一修改 | 工具/UI参数 | 结果 | 状态 |
|:---|:---|:---|:---|:---|:---|:---|:---|:---|
""",
        "05_prompts/video-prompt-log.md": """# 视频提示词日志

> 最终视频提示词固定使用【素材描述】【一句话概括】【画面内容描述】【全局补充】。

| 镜头ID | 路线 | Prompt版本 | 主/副案例 | 四段式已校验 | 输入顺序 | 唯一修改 | 字符数/平台 | 状态 |
|:---|:---|:---|:---|:---:|:---|:---|:---|:---|
""",
        "05_prompts/generation-log.md": """# 生成日志

| 生成ID | 图像/镜头ID | 输入 | 模型/UI参数 | 结果 | 通过项 | 失败维度 | 导演判断 | 下一步 |
|:---|:---|:---|:---|:---|:---|:---|:---|:---|
""",
        "06_reviews/review-log.md": """# 审片与返修日志

| 等级 | 镜头/时间码 | 可观察证据 | 问题维度 | 剪辑影响 | 只改什么 | 保留什么 | 验收标准 |
|:---:|:---|:---|:---|:---|:---|:---|:---|
""",
        "06_reviews/failure-library.md": """# 失败案例库

| 失败ID | 症状 | 根因 | 无效尝试 | 唯一有效修改 | 结果证据 | 适用边界 | 状态 |
|:---|:---|:---|:---|:---|:---|:---|:---|
""",
        "06_reviews/edit-needs.md": """# 粗剪缺失镜头

| 场次/镜头 | 缺失覆盖 | 剪辑用途 | 连续性条件 | 优先级 | 生成路线 | 状态 |
|:---|:---|:---|:---|:---:|:---|:---|
""",
        "06_reviews/cleanup-color-sound.md": """# 清理、调色与声音

| 镜头 | 清理问题 | 画面修复 | 相邻镜头色彩匹配 | 对白 | 环境/动作/音乐 | 状态 |
|:---|:---|:---|:---|:---|:---|:---|
""",
    }


def select_profile(pack: dict[str, str], profile: str) -> dict[str, str]:
    if profile == "micro":
        return {path: body for path, body in pack.items() if path in MICRO_INCLUDE}
    if profile == "standard":
        return {path: body for path, body in pack.items() if path not in LONGFORM_ONLY}
    return pack


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create a non-destructive AI film production project pack."
    )
    parser.add_argument("destination", help="Project directory to create or extend.")
    parser.add_argument("--title", default="未命名AI影视项目", help="Project title.")
    parser.add_argument(
        "--profile",
        choices=("micro", "standard", "longform"),
        default="standard",
        help="Production-document scale; duration alone does not decide it.",
    )
    parser.add_argument(
        "--merge",
        action="store_true",
        help="Create only missing files inside an existing directory; never overwrite.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Preview without writing.")
    parser.add_argument("--version", action="version", version=VERSION)
    return parser.parse_args()


def ensure_safe_target(target: Path) -> None:
    resolved = target.resolve()
    if resolved.parent == resolved:
        raise ValueError("Refusing to use a filesystem root as the project directory.")
    if resolved == Path.home().resolve():
        raise ValueError("Refusing to use the home directory as the project directory.")


def main() -> int:
    args = parse_args()
    target = Path(args.destination).expanduser().resolve()

    try:
        ensure_safe_target(target)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    if target.exists() and not target.is_dir():
        print(f"ERROR: destination is not a directory: {target}", file=sys.stderr)
        return 2

    existing = list(target.iterdir()) if target.exists() else []
    if existing and not args.merge:
        print(
            "ERROR: destination is not empty. Use --merge to create only missing files; "
            "existing files are never overwritten.",
            file=sys.stderr,
        )
        return 2

    pack = select_profile(templates(args.title, args.profile), args.profile)
    planned = [path for path in pack if not (target / path).exists()]
    skipped = [path for path in pack if (target / path).exists()]

    print(f"Target: {target}")
    print(f"Profile: {args.profile}")
    print(f"Create: {len(planned)} file(s); skip existing: {len(skipped)} file(s)")
    for path in planned:
        print(f"CREATE {path}")
    for path in skipped:
        print(f"SKIP   {path}")

    if args.dry_run:
        return 0

    target.mkdir(parents=True, exist_ok=True)
    for relative_path in planned:
        output_path = target / relative_path
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(pack[relative_path], encoding="utf-8", newline="\n")

    print("Project pack created without overwriting existing files.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
