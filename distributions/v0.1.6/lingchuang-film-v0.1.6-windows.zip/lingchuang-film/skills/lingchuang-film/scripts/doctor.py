"""Read-only dependency check; does not access API keys or remote services."""
import importlib.metadata
import json
import platform
import subprocess
import sys
from pathlib import Path
from deliver import ffmpeg

def check():
    result={'python':platform.python_version(),'platform':platform.system(),'dependencies':{},'shotcraft':'not_integrated','windows_editor':'requires_manual_version_and_open_test'}
    for name in ['pyJianYingDraft','imageio-ffmpeg','pymediainfo','imageio','Pillow']:
        try:result['dependencies'][name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:result['dependencies'][name]='missing'
    try:
        r=subprocess.run([ffmpeg(),'-version'],capture_output=True,timeout=15)
        result['ffmpeg']={'available':r.returncode==0,'version':r.stdout.decode(errors='replace').splitlines()[0]}
    except Exception as e:result['ffmpeg']={'available':False,'error':str(e)}
    result['ready']=all(v!='missing' for v in result['dependencies'].values()) and result['ffmpeg']['available']
    print(json.dumps(result,ensure_ascii=False,indent=2));return result['ready']

if __name__=='__main__':sys.exit(0 if check() else 1)
