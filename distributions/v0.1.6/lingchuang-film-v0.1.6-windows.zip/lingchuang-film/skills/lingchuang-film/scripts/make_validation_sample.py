"""Creates only a new synthetic local project; no API calls or third-party media."""
import argparse
from pathlib import Path
import json
import film
import deliver

def create(root):
    if root.exists():raise ValueError('样例目录已存在；使用新的空目录，绝不覆盖。')
    state=film.init(root,'commercial','Windows 剪映独立合成样例')
    assets=root/'assets';assets.mkdir()
    for i,color in enumerate(['0x174a6e','0x8b4a24'],1):
        target=assets/f'SC0{i}.mp4'
        deliver.run(['-f','lavfi','-i',f'color=c={color}:s=1280x720:r=25:d=4','-f','lavfi','-i',f'sine=frequency={330+i*110}:sample_rate=48000:duration=4','-vf',f'drawbox=x=100+{i*70}:y=150:w=350:h=250:color=white:t=4','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',target])
        aid=f'SC0{i}-v1';film.add_asset(root,state,aid,f'SC0{i}','v1',target.relative_to(root).as_posix(),'video');film.review_asset(root,state,aid,'approved','离线合成样例，仅测试流程');film.select_asset(root,state,aid)
    deliver.run(['-f','lavfi','-i','sine=frequency=220:sample_rate=48000:duration=8','-c:a','pcm_s16le',assets/'music.wav'])
    film.add_asset(root,state,'BGM-v1','BGM','v1','assets/music.wav','audio');film.review_asset(root,state,'BGM-v1','approved','离线合成测试音，不是第三方音乐');film.select_asset(root,state,'BGM-v1')
    film.write(root/'.film/project.json',state)
    spec=film.read(film.SKILL/'examples/edit.example.json')
    spec['subtitles'][0]['text']='灵创智影：字幕编辑测试'
    spec['subtitles'][1]['text']='第二镜头：原声与配乐分轨'
    film.write(root/'edit.json',spec)
    preview=deliver.preview(root,'edit.json',4)
    # Synthetic fixture only: this is not a real customer's approval or paid generation.
    deliver.approve_preview(root,preview['id'],'离线测试专用：模拟用户确认，不适用于真实客户项目')
    result=deliver.build(root,preview['id'])
    out=Path(result['delivery']);content=film.read(Path(result['draft'])/'draft_content.json')
    tracks=content['tracks'];types=[t['type'] for t in tracks]
    assert 'video' in types and 'audio' in types and 'text' in types,types
    assert sum(len(t['segments']) for t in tracks if t['type']=='video')==2
    info=deliver.media(out/'film.mp4')
    assert info['video'] and info['audio'] and abs(info['duration']-8)<0.15,info
    result['structural_checks']={'video_segments':2,'track_types':types,'mp4':info,'real_windows_open':'not verified'}
    film.write(root/'sample-result.json',result)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);a=p.parse_args()
    print(json.dumps(create(Path(a.project).resolve()),ensure_ascii=False,indent=2))
