"""Approved media -> review preview -> portable Windows Jianying draft and MP4."""
import argparse
import csv
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid
from film import read, write, local, digest, locked, event, stamp

def ffmpeg():
    configured = os.environ.get('LC_FILM_FFMPEG')
    if configured:
        if not Path(configured).is_file(): raise ValueError('LC_FILM_FFMPEG 指向的文件不存在。')
        return configured
    found = shutil.which('ffmpeg')
    if found: return found
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()

def run(args, cwd=None):
    r = subprocess.run([ffmpeg(), '-hide_banner', '-loglevel', 'error', '-nostdin', '-n', *map(str,args)], cwd=cwd, capture_output=True)
    if r.returncode:
        raise ValueError('FFmpeg 失败：'+r.stderr.decode('utf-8',errors='replace')[-2400:])

def media(path):
    from pymediainfo import MediaInfo
    tracks = MediaInfo.parse(str(path)).tracks
    duration = max((float(t.duration or 0)/1000 for t in tracks),default=0)
    return {'duration':duration,'video':any(t.track_type=='Video' for t in tracks),'audio':any(t.track_type=='Audio' for t in tracks)}

def seconds(value):
    v = float(value)
    if not math.isfinite(v) or v < 0: raise ValueError('时间和音量必须是非负有限数。')
    return v

def asset(root, state, asset_id):
    a = state['assets'][asset_id]
    if a['review'] != 'approved' or state['selected'].get(a['scene']) != asset_id:
        raise ValueError('交付只能使用最终选定且验收通过的素材：'+asset_id)
    p = local(root,a['path'])
    if digest(p.read_bytes()) != a['sha256']: raise ValueError('已确认素材内容发生变化：'+asset_id)
    return a,p

def validate(root, spec):
    state = read(root/'.film/project.json')
    if not spec.get('shots'): raise ValueError('剪辑清单缺少 shots。')
    if len(spec['shots']) > 200: raise ValueError('首版单片最多 200 镜，请分段制作。')
    settings = spec.get('video',{})
    for key, default in [('width',1280),('height',720),('fps',25)]:
        value=settings.get(key,default)
        if not isinstance(value,int) or value<=0 or (key!='fps' and (value%2 or value>7680)) or (key=='fps' and value>60):
            raise ValueError('无效视频规格：'+key)
    total=0
    used={}
    for shot in spec['shots']:
        if shot.get('transition','cut') != 'cut':
            raise ValueError('首版使用硬切；转场视频须作为已验收独立镜头插入。')
        aid=state['selected'].get(shot['scene_id'])
        if not aid: raise ValueError('镜头尚未选择最终素材：'+shot['scene_id'])
        a,p=asset(root,state,aid)
        if a['kind']!='video': raise ValueError('交付主轨须为视频，图片先制作成确认的视频片段。')
        info=media(p); start=seconds(shot.get('trim_in',0)); dur=seconds(shot['duration'])
        if not info['video'] or dur<=0 or start+dur>info['duration']+0.04: raise ValueError('镜头裁剪超出原片：'+aid)
        # Dialogue boundaries are source-relative. Reject clipping any declared line.
        for span in shot.get('dialogue_spans',[]):
            if len(span)!=2 or not (start <= seconds(span[0]) < seconds(span[1]) <= start+dur):
                raise ValueError('裁剪截断了已标注台词：'+aid)
        if shot.get('native_audio',True) and not info['audio'] and shot.get('dialogue_spans'):
            raise ValueError('有对白标注但没有音轨：'+aid)
        used[aid]=a['sha256'];total+=dur
    for row in spec.get('audio',[]):
        a,p=asset(root,state,row['asset_id']); info=media(p)
        start=seconds(row['start']);dur=seconds(row['duration']);source=seconds(row.get('source_in',0));volume=seconds(row.get('volume',1))
        if row['role'] not in ('dialogue','music','sfx') or not info['audio'] or dur<=0 or start+dur>total+0.04 or source+dur>info['duration']+0.04 or volume>4:
            raise ValueError('独立音轨参数无效。')
        used[row['asset_id']]=a['sha256']
    for row in spec.get('subtitles',[]):
        if not (0<=seconds(row['start'])<seconds(row['end'])<=total+0.04) or not isinstance(row['text'],str) or not row['text'].strip():
            raise ValueError('字幕文本或时间范围无效。')
    return state,total,digest(json.dumps({'edit':spec,'assets':used},ensure_ascii=False,sort_keys=True).encode())

def srt_time(sec):
    n=round(sec*1000);h,n=divmod(n,3600000);m,n=divmod(n,60000);s,n=divmod(n,1000)
    return f'{h:02d}:{m:02d}:{s:02d},{n:03d}'

def srt(rows):
    return '\n\n'.join(f'{i+1}\n{srt_time(r["start"])} --> {srt_time(r["end"])}\n{r["text"]}' for i,r in enumerate(rows))+'\n'

def duck_parts(start,duration,dialogue,normal,duck):
    end=start+duration
    cuts=sorted({start,end,*[max(start,min(end,t)) for pair in dialogue for t in pair]})
    return [(a,b,normal*(duck if any(x < b and y > a for x,y in dialogue) else 1)) for a,b in zip(cuts,cuts[1:]) if b>a]

def prepare(root,spec,state,out):
    (out/'media').mkdir(parents=True,exist_ok=False)
    settings=spec.get('video',{});w=settings.get('width',1280);h=settings.get('height',720);fps=settings.get('fps',25)
    clips=[];audio=[];native=[];dialogue=[];time=0
    for i,shot in enumerate(spec['shots']):
        aid=state['selected'][shot['scene_id']];a,p=asset(root,state,aid)
        src=out/'media'/f'source-{i:03d}{p.suffix.lower()}';shutil.copy2(p,src)
        dur=float(shot['duration']);trim=float(shot.get('trim_in',0));clip=out/'media'/f'clip-{i:03d}.mp4'
        run(['-ss',trim,'-i',src,'-t',dur,'-an','-vf',f'scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,fps={fps},setsar=1','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',clip])
        clips.append({'path':clip,'start':time,'duration':dur,'asset_id':aid,'source':src,'source_in':trim})
        if shot.get('native_audio',True) and media(p)['audio']:
            wav=out/'media'/f'native-{i:03d}.wav'
            run(['-ss',trim,'-i',src,'-t',dur,'-vn','-ar','48000','-ac','2','-c:a','pcm_s16le',wav])
            native.append({'path':wav,'start':time,'duration':dur,'source_in':0,'volume':1,'role':'native'})
            spans=shot.get('dialogue_spans')
            dialogue.extend([(time+float(x)-trim,time+float(y)-trim) for x,y in spans] if spans else [(time,time+dur)])
        time+=dur
    originals=[]
    for i,row in enumerate(spec.get('audio',[])):
        _,p=asset(root,state,row['asset_id']);target=out/'media'/f'audio-{i:03d}{p.suffix.lower()}';shutil.copy2(p,target)
        item={**row,'path':target,'source_in':float(row.get('source_in',0)),'volume':float(row.get('volume',1))}
        originals.append(item)
        if row['role']=='dialogue':dialogue.append((float(row['start']),float(row['start'])+float(row['duration'])))
    for item in originals:
        if item['role']=='music':
            duck=seconds(spec.get('music_duck',0.25))
            if duck>1:raise ValueError('music_duck 必须在 0–1。')
            for a,b,v in duck_parts(float(item['start']),float(item['duration']),dialogue,item['volume'],duck):
                audio.append({**item,'start':a,'duration':b-a,'source_in':item['source_in']+a-float(item['start']),'volume':v})
        else:audio.append(item)
    return clips,native+audio,time

def render(out,clips,audio,spec,total,limit=None):
    concat=out/'concat.txt'
    concat.write_text(''.join("file '"+c['path'].relative_to(out).as_posix()+"'\n" for c in clips),encoding='utf-8')
    silent=out/'silent.mp4';run(['-f','concat','-safe','0','-i','concat.txt','-c','copy',silent.name],cwd=out)
    subtitles=spec.get('subtitles',[])
    (out/'subtitles.srt').write_text(srt(subtitles),encoding='utf-8')
    args=['-i',silent.name]
    filters=[];labels=[]
    for i,a in enumerate(audio):
        args+=['-i',a['path'].relative_to(out).as_posix()]
        filters.append(f'[{i+1}:a]atrim=start={a["source_in"]}:duration={a["duration"]},asetpts=PTS-STARTPTS,volume={a["volume"]},adelay={round(a["start"]*1000)}|{round(a["start"]*1000)}[a{i}]')
        labels.append(f'[a{i}]')
    if labels:
        filters.append(''.join(labels)+f'amix=inputs={len(labels)}:normalize=0,alimiter=limit=0.95:level=0[mix]')
        args+=['-filter_complex',';'.join(filters),'-map','0:v:0','-map','[mix]']
    else:args+=['-map','0:v:0']
    if subtitles:args+=['-vf',"subtitles=subtitles.srt:force_style='Fontname=Microsoft YaHei,Fontsize=24,Alignment=2,MarginV=25'"]
    args+=['-t',min(total,limit) if limit else total,'-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','preview.mp4' if limit else 'film.mp4']
    run(args,cwd=out)

def draft(out,clips,audio,spec):
    import pyJianYingDraft as d
    settings=spec.get('video',{})
    name='lingchuang-'+uuid.uuid4().hex[:10]
    script=d.DraftFolder(str(out)).create_draft(name,settings.get('width',1280),settings.get('height',720),fps=settings.get('fps',25),allow_replace=False)
    script.append_track(d.TrackSpec(d.TrackType.video,name='最终确认视频'))
    for c in clips:
        # Use source media + trims: native editor remains able to extend/retrim each cut.
        seg=d.VideoSegment(str(c['source']),d.Timerange(round(c['start']*1e6),round(c['duration']*1e6)),source_timerange=d.Timerange(round(c['source_in']*1e6),round(c['duration']*1e6)),volume=0)
        script.add_segment(seg,'最终确认视频')
    # Separate lanes avoid overlap restrictions; role labels preserve editorial meaning.
    for i,a in enumerate(audio):
        label={'native':'原声对白','dialogue':'独立配音','music':'配乐','sfx':'音效'}[a['role']]+f'-{i+1}'
        script.append_track(d.TrackSpec(d.TrackType.audio,name=label))
        seg=d.AudioSegment(str(a['path']),d.Timerange(round(a['start']*1e6),round(a['duration']*1e6)),source_timerange=d.Timerange(round(a['source_in']*1e6),round(a['duration']*1e6)),volume=float(a['volume']))
        script.add_segment(seg,label)
    if spec.get('subtitles'):
        script.import_srt(str(out/'subtitles.srt'),'可编辑字幕',text_style=d.TextStyle(size=6,align=1),clip_settings=d.ClipSettings(transform_y=-0.75))
    script.save()
    folder=out/name
    meta=read(folder/'draft_meta_info.json');meta.update(draft_name=name,draft_fold_path=str(folder),draft_root_path=str(out),draft_id=str(uuid.uuid4()).upper())
    write(folder/'draft_meta_info.json',meta)
    # Store path slots, not a guessed global path replacement. Relink before import on any PC.
    content=read(folder/'draft_content.json');bindings=[]
    def walk(v,path):
        if isinstance(v,dict):
            for k,x in v.items():
                if k=='path' and isinstance(x,str) and Path(x).is_absolute():
                    resolved=Path(x).resolve()
                    if not resolved.is_relative_to(out.resolve()):raise ValueError('草稿含交付目录以外素材。')
                    bindings.append({'pointer':path+[k],'relative':resolved.relative_to(out).as_posix()})
                else:walk(x,path+[k])
        elif isinstance(v,list):
            for i,x in enumerate(v):walk(x,path+[i])
    walk(content,[])
    write(out/'draft-links.json',{'draft':name,'bindings':bindings})
    return folder

def relink(delivery):
    info=read(delivery/'draft-links.json');folder=local(delivery,info['draft']);content=read(folder/'draft_content.json')
    for entry in info['bindings']:
        path=local(delivery,entry['relative'])
        if not path.is_file():raise ValueError('交付素材缺失：'+entry['relative'])
        node=content
        for key in entry['pointer'][:-1]:node=node[key]
        node[entry['pointer'][-1]]=str(path)
    write(folder/'draft_content.json',content)
    meta=read(folder/'draft_meta_info.json');meta.update(draft_fold_path=str(folder),draft_root_path=str(delivery));write(folder/'draft_meta_info.json',meta)
    return folder

def install_draft(delivery,drafts_root):
    info=read(delivery/'draft-links.json')
    name=info['draft'];target=drafts_root/name
    if target.exists():raise ValueError('同名草稿已存在，不覆盖。')
    drafts_root.mkdir(parents=True,exist_ok=True)
    shutil.copytree(delivery,target)
    # Keep a complete portable copy in a uniquely named directory. Then flatten only own metadata.
    folder=relink(target)
    for name in ('draft_content.json','draft_meta_info.json'):
        shutil.copy2(folder/name,target/name)
    meta=read(target/'draft_meta_info.json');meta.update(draft_fold_path=str(target),draft_root_path=str(drafts_root));write(target/'draft_meta_info.json',meta)
    return target

def preview(root,edit_file,length):
    length=seconds(length)
    if length<=0 or length>30:raise ValueError('短预览长度须在 0–30 秒。')
    spec=read(local(root,edit_file));state,total,fingerprint=validate(root,spec)
    pid=uuid.uuid4().hex
    out=root/'film-previews'/pid;out.mkdir(parents=True,exist_ok=False)
    clips,audio,total=prepare(root,spec,state,out);render(out,clips,audio,spec,total,length)
    report={'id':pid,'fingerprint':fingerprint,'edit':edit_file,'seconds':min(length,total),'approved':False,'path':str((out/'preview.mp4').relative_to(root))}
    write(root/'.film/previews'/f'{pid}.json',report)
    return report

def approve_preview(root,pid,note):
    if not note.strip():raise ValueError('需要记录用户对声音和字幕短预览的确认。')
    record=read(local(root,f'.film/previews/{pid}.json'))
    _,_,fingerprint=validate(root,read(local(root,record['edit'])))
    if fingerprint!=record['fingerprint']:raise ValueError('剪辑或素材变化，需要重新预览。')
    record.update(approved=True,note=note,approved_at=stamp());write(root/'.film/previews'/f'{pid}.json',record)
    return record

def build(root,pid):
    record=read(local(root,f'.film/previews/{pid}.json'))
    if not record['approved']:raise ValueError('先由用户确认声音与字幕短预览。')
    spec=read(local(root,record['edit']));state,total,fingerprint=validate(root,spec)
    if fingerprint!=record['fingerprint']:raise ValueError('确认后发生变更，需要新的短预览。')
    out=root/'film-deliveries'/uuid.uuid4().hex;out.mkdir(parents=True,exist_ok=False)
    clips,audio,total=prepare(root,spec,state,out)
    render(out,clips,audio,spec,total);folder=draft(out,clips,audio,spec)
    write(out/'edit.json',spec)
    write(out/'provenance.json',{'preview_id':pid,'fingerprint':fingerprint,'selected':state['selected'],'assets':state['assets'],'stages':state['stages']})
    with (out/'costs.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(['stage','task_or_run','row_type','quote_id','estimated_points','actual_points','settlement_status'])
        for stage_id,row in state['stages'].items():
            q=row.get('quote',{})
            items=row.get('items',[])
            if items:
                for item in items:
                    writer.writerow([stage_id,item.get('task_id'),'task',q.get('id'),item.get('estimated_points'),item.get('actual_points_cost'),item.get('settlement_status','pending')])
            else:
                writer.writerow([stage_id,row.get('remote_id'),'stage',q.get('id'),q.get('estimated_points'),row.get('actual_points'),row.get('settlement_status','pending')])
    write(out/'final-review.json',{'status':'awaiting_user_review','mp4_sha256':digest((out/'film.mp4').read_bytes()),'note':None})
    write(out/'validation.json',{'render':'completed','duration':total,'draft_generated':True,'windows_open_verified':False,'subtitles_editable_verified':False,'audio_editable_verified':False,'note':'文件生成与结构检查不等于 Windows 剪映实际打开验收。'})
    (out/'打开草稿说明.txt').write_text('保持整个目录完整。移动后先运行本技能 deliver.py relink，再 install-draft 到已确认的剪映草稿根目录。首次打开检查画面、字幕与分轨声音。原声为独立音轨，可在剪映替换音色；替换后重新检查口型和字幕。',encoding='utf-8')
    return {'delivery':str(out),'mp4':str(out/'film.mp4'),'draft':str(folder)}

def accept_delivery(delivery,note):
    if not note.strip():raise ValueError('请记录用户对整片预览的实际确认。')
    review=read(delivery/'final-review.json')
    if digest((delivery/'film.mp4').read_bytes())!=review['mp4_sha256']:
        raise ValueError('成片已变化，需重新建立交付版本。')
    review.update(status='accepted',note=note,accepted_at=stamp());write(delivery/'final-review.json',review)
    return review

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    for name in ('preview','approve-preview','build'):
        p=sub.add_parser(name);p.add_argument('--project',required=True)
        if name=='preview':p.add_argument('--edit',required=True);p.add_argument('--seconds',type=float,default=8)
        else:p.add_argument('--preview',required=True)
        if name=='approve-preview':p.add_argument('--note',required=True)
    for name in ('relink','install-draft','accept-delivery'):
        p=sub.add_parser(name);p.add_argument('--delivery',required=True)
        if name=='install-draft':p.add_argument('--drafts-root',required=True)
        if name=='accept-delivery':p.add_argument('--note',required=True)
    a=parser.parse_args()
    if a.command in ('relink','install-draft','accept-delivery'):
        delivery=Path(a.delivery).resolve()
        if a.command=='accept-delivery':result=accept_delivery(delivery,a.note)
        else:result={'draft':str(relink(delivery) if a.command=='relink' else install_draft(delivery,Path(a.drafts_root).resolve()))}
    else:
        root=Path(a.project).resolve()
        with locked(root):
            if a.command=='preview':result=preview(root,a.edit,a.seconds)
            elif a.command=='approve-preview':result=approve_preview(root,a.preview,a.note)
            else:result=build(root,a.preview)
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
    try:main()
    except (ValueError,OSError,KeyError) as e:print('失败：'+str(e),file=sys.stderr);sys.exit(1)
