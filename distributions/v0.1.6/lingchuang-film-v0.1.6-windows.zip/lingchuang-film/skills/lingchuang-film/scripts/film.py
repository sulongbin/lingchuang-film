"""Local orchestration; v0.4.1 clients with structured error/recovery patch."""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import sys
import uuid
from datetime import datetime, timezone

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / 'modules/lingchuang-video/scripts'))
from lczyai import ApiError, redact

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, path)

def stamp():
    return datetime.now(timezone.utc).isoformat()

def local(root, value):
    p = (root / value).resolve()
    if not p.is_relative_to(root.resolve()):
        raise ValueError('文件必须位于本地项目内。')
    return p

@contextmanager
def locked(root):
    directory = root / '.film'
    directory.mkdir(parents=True, exist_ok=True)
    lock = directory / 'operation.lock'
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise ValueError('项目正由另一客户端操作；异常退出后先确认没有运行任务，再手动移走 operation.lock。')
    try:
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
        yield
    finally:
        lock.unlink(missing_ok=True)

def event(state, kind, **details):
    state['events'].append({'time': stamp(), 'kind': kind, **details})

def init(root, route, name):
    root.mkdir(parents=True, exist_ok=True)
    with locked(root):
        path = root / '.film/project.json'
        if path.exists():
            raise ValueError('项目已初始化；保留原项目，使用 inspect 接续。')
        state = {'schema': 1, 'id': str(uuid.uuid4()), 'name': name, 'route': route,
                 'stages': {}, 'assets': {}, 'selected': {}, 'events': []}
        event(state, 'initialized', route=route)
        write(path, state)
        return state

def manifest_hash(root, spec):
    # Bind approval to both the manifest and referenced bytes, not just filenames.
    files = {}
    def walk(value):
        if isinstance(value, dict):
            for key, val in value.items():
                if key in ('prompt_file', 'script_file') and val:
                    files[val] = digest(local(root, val).read_bytes())
                elif key in ('images', 'videos', 'audios') and isinstance(val, list):
                    for item in val:
                        p = local(root, item)
                        # Legacy audios can be existing IDs; no local file is implied.
                        if key != 'audios' or p.is_file():
                            files[item] = digest(p.read_bytes())
                else:
                    walk(val)
        elif isinstance(value, list):
            for val in value:
                walk(val)
    walk(spec)
    return digest(json.dumps({'spec': spec, 'files': files}, ensure_ascii=False, sort_keys=True).encode())

def client_for(root, name):
    sys.path.insert(0, str(SKILL / 'modules/lingchuang-video/scripts'))
    from production import ProductionClient
    from nsdd import NsddClient
    from lczyai import Client
    return {'production': ProductionClient, 'nsdd': NsddClient, 'legacy': Client}[name](str(root))

def normalize_quote(q):
    amount = q.get('reservedPoints', q.get('estimated_points'))
    if amount is None:
        raise ValueError('报价缺少确认金额，停止提交。')
    return {'id': q.get('quote_id', q.get('id')), 'approval_points': amount,
            'estimated_points': q.get('estimated_points', q.get('minPoints')),
            'maximum_points': q.get('maxPoints', amount), 'raw': q}

def plan(root, state, stage_id, kind, client, manifest):
    if stage_id in state['stages']:
        raise ValueError('阶段编号已存在；使用原阶段恢复，改方案用新的阶段编号。')
    spec = read(local(root, manifest))
    fingerprint = manifest_hash(root, spec)
    row = {'kind': kind, 'client': client, 'manifest': manifest, 'fingerprint': fingerprint,
           'plan_approved': False, 'cost_approved': False, 'status': 'planned', 'history': []}
    state['stages'][stage_id] = row
    event(state, 'plan', stage=stage_id, fingerprint=fingerprint)
    return row

def unchanged(root, row):
    if manifest_hash(root, read(local(root, row['manifest']))) != row['fingerprint']:
        raise ValueError('方案或素材已变化，原确认失效；请建立新阶段并重新确认。')

def quote_stage(root, state, stage_id, factory=client_for):
    row = state['stages'][stage_id]
    unchanged(root, row)
    if not row['plan_approved']:
        raise ValueError('先展示方案并记录会员确认。')
    if row.get('quote'):
        return row['quote']  # recovery does not create another quote
    client = factory(root, row['client'])
    catalog = {m['id']: m for m in client.models()['models']}
    spec = read(local(root, row['manifest']))
    scenes = [spec] if row['client'] == 'nsdd' else spec.get('scenes', [])
    for scene in scenes:
        model_id = scene.get('model', spec.get('workflow', {}).get('generate', {}).get('model'))
        if model_id not in catalog:
            raise ValueError('实时会员目录没有此模型，禁止提交。')
        model = catalog[model_id]
        kind = model.get('kind', 'video')
        processing = model.get('stage', '')
        expected = 'video' if row['kind'] in ('depth','upscale') else row['kind']
        if kind != expected:
            raise ValueError('同一阶段不能混合图片、视频或声音；请拆分并分别确认。')
        if row['kind']=='depth' and processing!='video_depth':
            raise ValueError('白膜阶段只能使用目录明确标记 video_depth 的模型。')
        if row['kind']=='upscale' and not (processing in ('upscale','h3_2k') or (row['client']=='nsdd' and model.get('processing'))):
            raise ValueError('超分阶段必须使用已适配的处理模型。')
    q = client.prepare(row['manifest']) if row['client'] == 'legacy' else client.quote(row['manifest'])
    row['quote'] = normalize_quote(q)
    row['status'] = 'quoted'
    event(state, 'quote', stage=stage_id, quote_id=row['quote']['id'])
    return row['quote']

def approve_plan(root, state, stage_id, confirmation, note):
    row = state['stages'][stage_id]
    unchanged(root, row)
    if confirmation != row['fingerprint'] or not note.strip():
        raise ValueError('方案确认必须匹配当前摘要，并记录会员原意。')
    row['plan_approved'] = True
    event(state, 'plan-approved', stage=stage_id, note=note)
    return row

def approve_cost(root, state, stage_id, quote_id, amount, note):
    from decimal import Decimal
    row = state['stages'][stage_id]
    unchanged(root, row)
    if row['status'] not in ('quoted', 'insufficient_balance'):
        raise ValueError('当前阶段不可确认旧费用；先核对提交或刷新有效报价。')
    q = row['quote']
    if quote_id != q['id'] or Decimal(str(amount)) != Decimal(str(q['approval_points'])) or not note.strip():
        raise ValueError('确认报价 ID、预扣金额或确认说明不匹配。')
    row['cost_approved'] = True
    event(state, 'cost-approved', stage=stage_id, quote_id=quote_id, points=q['approval_points'], note=note)
    return row

def error_record(exc):
    if isinstance(exc, ApiError):
        return exc.as_dict()
    return {'http_status': None, 'code': None,
            'message': redact(str(exc), os.environ.get('LCZYAI_API_KEY', ''))}

def rejection_state(exc, client):
    # Audited POST /production/runs checks runId before these rejection codes,
    # and performs them before creating the run. No status-only or text matching.
    if (isinstance(exc, ApiError) and client in ('production', 'legacy')
            and exc.method == 'POST' and exc.endpoint == '/api/v1/production/runs'):
        if exc.http_status == 409 and exc.code in ('quote_expired', 'quote_changed'):
            return 'requote_required'
        if exc.http_status == 402 and exc.code == 'insufficient_points':
            return 'insufficient_balance'
    return 'unknown'

def locally_expired(row):
    raw = row['quote']['raw']
    expires = raw.get('expires_at', raw.get('expiresAt'))
    # Existing services return Unix milliseconds. An absent/unknown format is
    # not guessed; server validation remains authoritative.
    return (isinstance(expires, (int, float)) and not isinstance(expires, bool)
            and expires <= datetime.now(timezone.utc).timestamp() * 1000)

def submit(root, state, stage_id, retry_original=False, factory=client_for):
    row = state['stages'][stage_id]
    unchanged(root, row)
    if row.get('remote_id'):
        return {'remote_id': row['remote_id'], 'message': '原任务已提交，使用 sync 查询。'}
    if row['status'] == 'requote_required':
        raise ValueError('旧报价不可再提交；请刷新报价并重新确认。')
    if not row['plan_approved'] or not row['cost_approved']:
        raise ValueError('缺少本阶段方案或费用确认。')
    if row['status'] in ('submitting', 'unknown') and not retry_original:
        raise ValueError('提交结果待核对；不得新建报价重做，可显式重放原报价 --retry-original。')
    if row['status'] not in ('submitting', 'unknown') and locally_expired(row):
        row.update(status='requote_required', cost_approved=False)
        row['last_error'] = {'http_status': None, 'code': 'local_quote_expired',
                             'message': '本地检查报价已到期，本次未发送提交；请刷新并重新确认。'}
        event(state, 'quote-expired-locally', stage=stage_id, quote_id=row['quote']['id'])
        write(root / '.film/project.json', state)
        raise ValueError(row['last_error']['message'])
    row['status'] = 'submitting'
    event(state, 'submit-start', stage=stage_id, quote_id=row['quote']['id'])
    write(root / '.film/project.json', state)  # persist BEFORE remote side effect
    try:
        result = factory(root, row['client']).submit(row['quote']['id'], row['quote']['id'])
    except Exception as exc:
        row['status'] = rejection_state(exc, row['client'])
        row['last_error'] = error_record(exc)
        if row['status'] == 'requote_required':
            row['cost_approved'] = False
        event(state, 'submit-error', stage=stage_id, status=row['status'], error=row['last_error'])
        write(root / '.film/project.json', state)
        raise
    row['remote_id'] = result.get('run_id', result.get('taskId'))
    if not row['remote_id']:
        row['status'] = 'unknown'
        write(root / '.film/project.json', state)
        raise ValueError('响应缺少任务编号，保留原报价核对。')
    row['status'] = result.get('status', 'submitted')
    row['result'] = result
    row.pop('last_error', None)
    event(state, 'submitted', stage=stage_id, remote_id=row['remote_id'])
    return result

def refresh(root, state, stage_id, factory=client_for):
    row = state['stages'][stage_id]
    if row.get('remote_id') or row['status'] in ('submitting', 'unknown'):
        raise ValueError('已提交或结果未知，不允许刷新报价。')
    unchanged(root, row)
    # Server may supersede the old quote before the new response is received.
    # Persist invalidation before calling it; never restore the old approval.
    row.update(cost_approved=False, status='requote_required')
    write(root / '.film/project.json', state)
    try:
        q = factory(root, row['client']).requote(row['quote']['id'])
        return accept_refreshed(root, state, stage_id, q)
    except Exception as exc:
        row['last_error'] = error_record(exc)
        event(state, 'requote-error', stage=stage_id, error=row['last_error'])
        write(root / '.film/project.json', state)
        raise

def accept_refreshed(root, state, stage_id, q):
    row = state['stages'][stage_id]
    fresh = normalize_quote(q)
    if not fresh['id'] or fresh['id'] == row['quote']['id']:
        raise ValueError('服务端未返回新的有效报价编号；保持待核对。')
    row['history'].append(row['quote'])
    row['quote'] = fresh
    row['cost_approved'] = False
    row['status'] = 'quoted'
    row.pop('last_error', None)
    event(state, 'requote', stage=stage_id, quote_id=row['quote']['id'])
    write(root / '.film/project.json', state)
    return row['quote']

def recover(root, state, stage_id, factory=client_for):
    row = state['stages'][stage_id]
    if row.get('remote_id') or row['status'] not in ('unknown', 'submitting'):
        raise ValueError('此恢复入口仅用于没有任务编号的 unknown/submitting 阶段。')
    unchanged(root, row)
    row['status'] = 'unknown'
    write(root / '.film/project.json', state)
    try:
        result = factory(root, row['client']).recover_quote(row['quote']['id'])
        if result.get('run', {}).get('run_id'):
            run = result['run']
            row.update(remote_id=run['run_id'], status=run.get('status', 'submitted'), result=run)
            event(state, 'recovered-original-run', stage=stage_id, remote_id=row['remote_id'])
            write(root / '.film/project.json', state)
            return run
        if result.get('verification') != 'server_atomic_refresh' or not result.get('quote'):
            raise ValueError('服务端未能明确确认原报价未提交；保留 unknown。')
        event(state, 'recovery-verified', stage=stage_id, quote_id=row['quote']['id'],
              evidence='server_atomic_refresh')
        return accept_refreshed(root, state, stage_id, result['quote'])
    except Exception as exc:
        row['last_error'] = error_record(exc)
        event(state, 'recovery-unresolved', stage=stage_id, error=row['last_error'])
        write(root / '.film/project.json', state)
        raise

def sync(root, state, stage_id, download=False, factory=client_for):
    row = state['stages'][stage_id]
    if not row.get('remote_id'):
        raise ValueError('没有已知任务编号，请先核对原提交。')
    client = factory(root, row['client'])
    result = client.status(row['remote_id'])
    row['result'] = result
    row['status'] = result.get('status', 'unknown')
    row['settlement_status'] = result.get('settlement_status', result.get('settlementStatus', 'pending'))
    # Missing actual charges stay null, never coerced to zero.
    row['actual_points'] = result.get('settled_points', result.get('actualPoints'))
    row['items'] = result.get('items', [])
    if download:
        row['downloads'] = client.download(row['remote_id'])
    event(state, 'sync', stage=stage_id, status=row['status'], settlement=row['settlement_status'])
    return row

def add_asset(root, state, asset_id, scene, version, path, kind, parent=None, stage=None):
    if asset_id in state['assets']:
        raise ValueError('资产 ID 已存在；新版本使用新 ID。')
    if parent and parent not in state['assets']:
        raise ValueError('来源资产不存在。')
    if stage and stage not in state['stages']:
        raise ValueError('来源阶段不存在。')
    p = local(root, path)
    asset = {'scene': scene, 'version': version, 'path': path, 'kind': kind,
             'sha256': digest(p.read_bytes()), 'parent': parent, 'stage': stage, 'review': 'pending'}
    state['assets'][asset_id] = asset
    event(state, 'asset', asset=asset_id)
    return asset

def review_asset(root, state, asset_id, decision, note):
    a = state['assets'][asset_id]
    if digest(local(root, a['path']).read_bytes()) != a['sha256']:
        raise ValueError('资产内容已改变，必须建立新版本。')
    if not note.strip():
        raise ValueError('请记录用户验收意见。')
    a['review'] = decision
    event(state, 'review', asset=asset_id, decision=decision, note=note)
    return a

def select_asset(root, state, asset_id):
    a = state['assets'][asset_id]
    if a['review'] != 'approved':
        raise ValueError('只能选用明确验收通过的版本。')
    if digest(local(root, a['path']).read_bytes()) != a['sha256']:
        raise ValueError('资产字节变化，不能沿用旧验收。')
    state['selected'][a['scene']] = asset_id
    event(state, 'selected', scene=a['scene'], asset=asset_id)
    return a

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project', required=True)
    sub = p.add_subparsers(dest='command', required=True)
    q = sub.add_parser('init'); q.add_argument('--route', choices=['drama', 'commercial'], required=True); q.add_argument('--name', required=True)
    sub.add_parser('inspect')
    q = sub.add_parser('models'); q.add_argument('--client', choices=['production','nsdd','legacy'], required=True)
    q = sub.add_parser('plan'); q.add_argument('stage'); q.add_argument('--kind', choices=['image', 'video', 'audio', 'depth', 'upscale'], required=True); q.add_argument('--client', choices=['production', 'nsdd', 'legacy'], required=True); q.add_argument('--manifest', required=True)
    q = sub.add_parser('approve-plan'); q.add_argument('stage'); q.add_argument('--confirm', required=True); q.add_argument('--note', required=True)
    q = sub.add_parser('approve-cost'); q.add_argument('stage'); q.add_argument('--quote', required=True); q.add_argument('--points', required=True); q.add_argument('--note', required=True)
    for name in ['quote', 'requote', 'recover', 'sync', 'download', 'submit']:
        q = sub.add_parser(name); q.add_argument('stage')
        if name == 'submit': q.add_argument('--retry-original', action='store_true')
    q = sub.add_parser('asset'); q.add_argument('id'); q.add_argument('--scene', required=True); q.add_argument('--version', required=True); q.add_argument('--path', required=True); q.add_argument('--kind', choices=['image','video','audio','depth'], required=True); q.add_argument('--parent'); q.add_argument('--stage')
    q = sub.add_parser('review'); q.add_argument('id'); q.add_argument('--decision', choices=['approved','rejected'], required=True); q.add_argument('--note', required=True)
    q = sub.add_parser('select'); q.add_argument('id')
    args = p.parse_args()
    root = Path(args.project).resolve()
    if args.command == 'init': result = init(root, args.route, args.name)
    else:
        with locked(root):
            state = read(root / '.film/project.json')
            c = args.command
            if c == 'inspect': result = state
            elif c == 'models': result = client_for(root,args.client).models()
            elif c == 'plan': result = plan(root,state,args.stage,args.kind,args.client,args.manifest)
            elif c == 'approve-plan': result = approve_plan(root,state,args.stage,args.confirm,args.note)
            elif c == 'approve-cost': result = approve_cost(root,state,args.stage,args.quote,args.points,args.note)
            elif c == 'quote': result = quote_stage(root,state,args.stage)
            elif c == 'requote': result = refresh(root,state,args.stage)
            elif c == 'recover': result = recover(root,state,args.stage)
            elif c == 'submit': result = submit(root,state,args.stage,args.retry_original)
            elif c in ('sync','download'): result = sync(root,state,args.stage,c=='download')
            elif c == 'asset': result = add_asset(root,state,args.id,args.scene,args.version,args.path,args.kind,args.parent,args.stage)
            elif c == 'review': result = review_asset(root,state,args.id,args.decision,args.note)
            else: result = select_asset(root,state,args.id)
            write(root / '.film/project.json',state)
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__ == '__main__':
    try: main()
    except (ValueError,OSError,KeyError) as e:
        key = os.environ.get('LCZYAI_API_KEY','')
        message = str(e).replace(key,'[已隐藏]') if key else str(e)
        print('失败：'+message,file=sys.stderr); sys.exit(1)
