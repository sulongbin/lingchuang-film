﻿[CmdletBinding()]
param(
    [string]$UserRoot = $env:USERPROFILE,
    [string]$PythonExecutable = 'python',
    [switch]$SkipDependencies
)
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'install.ps1') -App Codex -CallerApp Codex -UserRoot $UserRoot -PythonExecutable $PythonExecutable -SkipDependencies:$SkipDependencies
