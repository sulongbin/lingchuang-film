import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("film_entry", ROOT / "scripts/film_entry.py")
entry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(entry)


class EntryTest(unittest.TestCase):
    def test_original_clients_still_match_reviewed_bridge(self):
        for name, digest in entry.CLIENT_HASHES.items():
            self.assertEqual(entry.hashlib.sha256((ROOT / name).read_bytes()).hexdigest(), digest)

    def test_missing_cli_never_falls_back_to_existing_key(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(entry.subprocess, "run") as run:
            with self.assertRaisesRegex(ValueError, "不会自动改用旧 Key"):
                entry.command(["--project", tmp, "models"], environ={"LOCALAPPDATA":tmp,"LCZYAI_API_KEY":"fixture"})
            run.assert_not_called()

    def test_explicit_key_keeps_original_entry_and_environment(self):
        args, env = entry.command(["--transport","key","--project","作品 空格","inspect"], environ={"LCZYAI_API_KEY":"fixture"})
        self.assertEqual(args, [sys.executable,str(ROOT / "scripts/film.py"),"--project","作品 空格","inspect"])
        self.assertEqual(env["LCZYAI_API_KEY"], "fixture")

    def test_cli_routes_exact_arguments_without_legacy_key(self):
        with tempfile.TemporaryDirectory() as tmp:
            bridge = Path(tmp) / "LingchuangCLIApp/film_cli_bridge.py"
            bridge.parent.mkdir()
            bridge.write_bytes(b"test bridge")
            digest = entry.hashlib.sha256(bridge.read_bytes()).hexdigest()
            version = subprocess.CompletedProcess([],0,json.dumps({"ok":True,"data":{"version":"0.1.1"}}),"")
            with patch.object(entry,"BRIDGE_HASH",digest), patch.object(entry.subprocess,"run",return_value=version) as run:
                args, env = entry.command(["--project","作品 空格","models","--client","nsdd"], environ={"LOCALAPPDATA":tmp,"LCZYAI_API_KEY":"fixture"})
                self.assertEqual(args[1:4], [str(bridge),"--skill-root",str(ROOT)])
                self.assertEqual(args[4:], ["--project","作品 空格","models","--client","nsdd"])
                self.assertNotIn("LCZYAI_API_KEY",env)
                self.assertNotIn("LCZYAI_API_KEY",run.call_args.kwargs["env"])
                version.stdout = json.dumps({"ok":True,"data":{"version":"0.2.0"}})
                with self.assertRaisesRegex(ValueError,"版本检查失败"):
                    entry.command(["models"],environ={"LOCALAPPDATA":tmp})

    def test_failure_exit_propagates_once_without_retry(self):
        with patch.object(entry,"command",return_value=(["fixture"],{})), patch.object(entry.subprocess,"call",return_value=1) as call:
            self.assertEqual(entry.main(["submit","fixture"]),1)
            call.assert_called_once()


if __name__ == "__main__":
    unittest.main()
