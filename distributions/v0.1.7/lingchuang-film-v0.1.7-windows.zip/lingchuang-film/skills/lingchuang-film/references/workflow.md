> v0.1.7 默认使用 CLI 浏览器授权；先读 [接入说明](cli-login.md)。示例中的技能根和作品根必须替换为实际路径。仅在用户明确选择旧 Key 方式时，加 `--transport key`。

# 本地状态与平台生产

所有示例以 PowerShell 为例。`$skill` 指安装后的 `lingchuang-film` 根目录，`$project` 指自己的项目。先赋实际路径；其余大写编号与摘要替换为命令返回值。不要原样执行占位符。使用安装时生成的虚拟环境 Python（或已安装依赖的 Python）。

```powershell
# Codex：.agents；WorkBuddy：.workbuddy。选与实际安装一致的一项。
$skill = Join-Path $env:USERPROFILE '.agents/skills/lingchuang-film'
# WorkBuddy 使用：$skill = Join-Path $env:USERPROFILE '.workbuddy/skills/lingchuang-film'
$project = 'D:\我的影视项目'
python "$skill/scripts/film_entry.py" --project "$project" init --route commercial --name '我的作品'
# 已有项目不再 init：
python "$skill/scripts/film_entry.py" --project "$project" inspect
python "$skill/scripts/film_entry.py" --project "$project" models --client production
python "$skill/scripts/film_entry.py" --project "$project" models --client nsdd
```

drama 为短剧，commercial 为商业。初始化只创建 `.film/`，不覆盖已有文件，不更改 `.lczyai/`。一个项目对应一个作品。原客户端沿用同一会员和画布绑定；首次创建画布的首批提交完成后，才跨入口追加。客户切换会员使用独立项目。

## 准备生产清单

- 全流程模型用 [production.py 清单](../modules/lingchuang-video/references/fullflow.md)。
- nsdd 用 [专用清单](../modules/lingchuang-video/references/nsdd.md)。
- 旧 H3 用 [旧生产清单](../modules/lingchuang-video/references/production-plan.md)。

三个客户端保留原命令和缓存协议，附结构化错误与报价恢复补丁，历史项目可继续直接运行。新增协调脚本不迁移旧报价记录；已有 run_id/task_id 仍从其原入口查询。需要接续剪辑时登记历史最终素材，不重新提交。

下面的 `image-plan.json` 是会员在项目中创建的文件，不是包内附件。可从 [全流程 API 内嵌示例](../modules/lingchuang-video/references/api-fullflow.md) 复制并改为当前项目内容。

```powershell
python "$skill/scripts/film_entry.py" --project "$project" plan images-v1 --kind image --client production --manifest image-plan.json
# 给用户展示方案；用户确认后，填写返回的完整 fingerprint 与真实确认意见：
python "$skill/scripts/film_entry.py" --project "$project" approve-plan images-v1 --confirm PLAN_FINGERPRINT --note '用户确认的人物资产方案'
python "$skill/scripts/film_entry.py" --project "$project" quote images-v1
# 展示 estimated_points、maximum_points、approval_points 及逐项 raw 报价。
# 会员明确确认本次有效报价后，填写真实 ID 和预扣上限：
python "$skill/scripts/film_entry.py" --project "$project" approve-cost images-v1 --quote QUOTE_ID --points 2 --note '用户确认本次报价和预扣上限'
python "$skill/scripts/film_entry.py" --project "$project" submit images-v1
python "$skill/scripts/film_entry.py" --project "$project" sync images-v1
python "$skill/scripts/film_entry.py" --project "$project" download images-v1
```

示例 `2` 仅演示数值位置，不是固定价格。`approve-cost` 金额必须精确等于该报价的 approval_points，所有确认均来自用户，不可自动填“已确认”。`--kind` 支持 image/video/audio/depth/upscale；`--client` 支持 production/nsdd/legacy。同阶段不混图片、视频和声音；混合依赖分批处理。

`plan` 摘要绑定清单及引用文件内容，内容变化需新阶段。`requote STAGE_ID` 仅可刷新未提交的报价，刷新前费用确认即失效。`submit --retry-original` 仅在核对提交响应丢失时显式重放同一报价，不新建任务。正常重复 submit 返回已有编号。unknown/reconciliation 不能自动切备用；历史误记阶段用 `recover STAGE_ID` 经服务端原子校验恢复，不能直接修改本地状态。明确错误码、余额恢复、命令及 nsdd 限制见 [报价恢复](quote-recovery.md)。

## 素材版本

下载后把具体成功结果登记到资产表，`--stage` 绑定费用与远端任务。已存在的本地素材可以不传 stage。ID 永不覆盖；返修、超分、白膜使用新 ID 和 `--parent`。

```powershell
python "$skill/scripts/film_entry.py" --project "$project" asset SC01-v1 --scene SC01 --version v1 --path outputs/RUN_ID/RESULT.mp4 --kind video --stage videos-v1
python "$skill/scripts/film_entry.py" --project "$project" review SC01-v1 --decision approved --note '用户确认采用此镜头'
python "$skill/scripts/film_entry.py" --project "$project" select SC01-v1
```

资产登记只存项目相对路径、摘要、版本、父资产、阶段和验收状态。`select` 不等于生成，后续新版本不会自动替换已选版本。拒绝版可 review rejected 留档；已选版后续被拒绝时，交付检查会阻止导出。

费用保存在 `.film/project.json` 的 stages：quote 为完整报价，history 为历史报价，result/items 保存服务端响应。未结算 actual_points 保持 null，逐任务 actual_points_cost 与 settlement_status 按原响应保留。不得把阶段总计与逐任务明细相加两次。历史客户端缓存与其画布字段仍在 `.lczyai/`。

`.film/operation.lock` 防止本地并行协调写入。程序异常退出后，先确认无进程正在处理该项目，再将旧锁文件移走；不能通过清空 `.film` 或 `.lczyai` 恢复。
