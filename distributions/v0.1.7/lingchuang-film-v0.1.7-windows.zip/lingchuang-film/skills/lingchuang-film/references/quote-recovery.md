> v0.1.7 默认使用 CLI 浏览器授权；先读 [接入说明](cli-login.md)。示例中的技能根和作品根必须替换为实际路径。仅在用户明确选择旧 Key 方式时，加 `--transport key`。

# 报价过期与提交恢复（v0.1.2 文档更新）

本补丁只修复客户端错误传递和本地状态恢复，不改变模型、价格、报价有效期或服务端流程。恢复命令不会自动提交或确认新费用。

## 状态和依据

| 情况 | 本地状态 | 后续操作 |
|---|---|---|
| production/legacy 提交接口返回 HTTP 409 + quote_expired / quote_changed | requote_required；清除旧费用确认 | requote，展示完整新报价后重新确认 |
| 同一接口返回 HTTP 402 + insufficient_points | insufficient_balance；保留原报价和确认 | 用户补足余额后，报价有效则 submit 原报价；过期则 requote |
| 尚无未知提交记录，本地报价时间已到期 | requote_required；本次不发送提交 | requote，服务端仍为最终依据 |
| 超时、响应丢失、缺少编号、无明确含义的 409/5xx | unknown | 核对或显式重放同一报价；不能普通 requote |
| 原来已是 unknown，但本地报价现已过期 | 仍是 unknown | 本地时钟不能证明之前没有提交；使用 recover 或重放原报价 |

匹配依据是 HTTP 状态、服务端 code、请求方法、确切接口路径和入口类型的组合，不匹配中文说明。依据已核对的 `server/member-production.mjs`：`POST /api/v1/production/runs` 先返回已存在的 runId，再检查过期和变化；余额检查位于持久化任务之前。任务内的 error_code 或结算不足不是首次提交未受理的证据。

`ApiError` 继承 ValueError，旧客户端异常处理继续兼容；保留 http_status/code/message/method/endpoint。密钥和 Bearer 凭证在构造异常时脱敏，状态文件只存脱敏后的 last_error 及事件。原始响应体、请求头和密钥不写入状态。

## 明确未受理的报价

`$skill` 是本版技能根目录，`$project` 是原项目；python 使用已安装依赖的解释器。示例编号、金额必须替换成实际返回值。

```powershell
python "$skill/scripts/film_entry.py" --project "$project" inspect
python "$skill/scripts/film_entry.py" --project "$project" requote videos-v1
# 展示 raw 中逐项参数、estimated_points、maximum_points、approval_points 与有效期。
# 等待用户确认新报价后才能执行以下两步：
python "$skill/scripts/film_entry.py" --project "$project" approve-cost videos-v1 --quote NEW_QUOTE_ID --points 3 --note '用户对新报价的真实确认意见'
python "$skill/scripts/film_entry.py" --project "$project" submit videos-v1
```

示例 3 不是固定售价。刷新前即撤销旧费用确认；即使刷新响应丢失，也不会恢复旧确认。新报价的参数、金额和预扣上限全部重新展示，不自动切换模型、续确认或生成。新报价保留 raw，旧报价追加 history。

## 历史 unknown / submitting 阶段

```powershell
python "$skill/scripts/film_entry.py" --project "$project" recover videos-v1
```

该命令只适用于没有 remote_id 的未知阶段，不会调用生成接口：

1. production/legacy 先通过服务端任务列表和任务查询寻找原报价。找到则恢复原 run_id，只跟踪原任务。
2. 查不到不等于未提交。使用现有 `POST /api/v1/production/quotes/:id/refresh` 或 `POST /api/v1/linhai/quotes/:id/refresh` 做服务端原子核验：服务端按对应入口的合同核验原报价及任务，确认可以安全作废后，将旧报价 superseded 并产生新报价。仅收到有效的新报价才能解除 unknown。这样避免“先查没有任务，再本地重置”的竞争窗口。
3. 成功后状态为 quoted，费用确认始终为 false；直接展示返回的新报价，等用户确认，不必再调用一次 requote。
4. 409、404、权限失败、响应超时、损坏响应等均保留 unknown 和旧报价。不能把列表为空、任务 404、过期时间或旧错误文字当作未提交证明。不能删缓存、批量重置阶段或用新阶段绕过。

现有接口没有 GET 报价状态接口。上面的刷新 POST 是带服务端未提交检查的报价操作，会创建未扣费报价；并非普通只读 GET。不伪造额外查询端点。若原报价已被服务端清理而无法核验，本地保留 unknown，交由平台人工核对。

原报价重放仍使用：

```powershell
python "$skill/scripts/film_entry.py" --project "$project" submit videos-v1 --retry-original
```

重放必须沿用原 ID、原费用确认及幂等服务端；不能新建报价。查询到已创建任务时采用原任务，绝不第二次生成。

## nsdd 平台恢复方式

平台已于 2026-10-03 发布结构化错误及安全刷新补丁。刷新会在生产存储事务内核验原报价和任务：无实际任务，或带明确 insufficient_points、not_charged 且没有预扣/上游证据的拒绝记录，才可作废旧报价并取得新报价。已受理、不确定、证据不完整或权限不符继续拒绝刷新；重复刷新沿用已保存的替代报价。

本包仍使用 v0.1.1 的保守客户端分类：nsdd 的提交拒绝可能记为 unknown，不能直接按 production 的 requote 路径处理。没有 remote_id 时执行上述 recover，由服务端核验；返回新报价后必须重新确认。明确余额不足、补足余额且原报价仍有效时，可在用户明确要求后使用 submit --retry-original；若已返回 remote_id，先 sync 核对原任务，不自动绕过状态或创建新阶段。此文档更新没有更改本地状态机。

历史记录缺少可靠证据时，服务端仍会拒绝恢复，需要平台人工核对。任何无 code 的 409/402、网络超时、含义不明的错误都不能作为未受理证明。不得删除提交意图、缓存或批量重置。恢复不自动确认、不更换模型、不触发新生成。

## 验证范围

新增测试覆盖明确拒绝的恢复、余额不足重试、过期后的重新确认、未知错误门禁、服务端核验、原任务幂等、脱敏和三个客户端。全部离线模拟；不声明真实付费接口已实测。剪映相关代码和素材资源未变，本次不重复认证编辑器兼容性。
