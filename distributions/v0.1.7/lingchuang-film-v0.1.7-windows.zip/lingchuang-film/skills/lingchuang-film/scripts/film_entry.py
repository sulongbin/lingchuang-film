"""Select CLI transport explicitly; preserve the original film workflow unchanged."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

SKILL = Path(__file__).resolve().parents[1]
BRIDGE_HASH = "9722b48f53bb09bc9ebd542e11ad083c9778d517cc834e6ab2527005a6d1404d"
CLIENT_HASHES = {
    "scripts/film.py": "0488aa973ead8644a95eff536072989553595c642bb81c3d60010e8e0eca278c",
    "modules/lingchuang-video/scripts/lczyai.py": "1ddbfcc5197185b6782298289c9a50ec90d58165f5588fee1001a3a5faf14fe3",
}


def command(argv, skill=SKILL, environ=None):
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--transport", choices=("cli", "key"), default="cli")
    options, remaining = parser.parse_known_args(argv)
    env = dict(os.environ if environ is None else environ)
    env["PYTHONUTF8"] = "1"
    if options.transport == "key":
        return [sys.executable, str(skill / "scripts/film.py"), *remaining], env
    if not env.get("LOCALAPPDATA"):
        raise ValueError("CLI 接入仅支持 Windows；找不到 LOCALAPPDATA。")
    cli = Path(env["LOCALAPPDATA"]) / "LingchuangCLIApp"
    bridge = cli / "film_cli_bridge.py"
    for file, expected in [(skill / name, value) for name, value in CLIENT_HASHES.items()] + [(bridge, BRIDGE_HASH)]:
        if not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest() != expected:
            raise ValueError("CLI 或技能版本未匹配，请核对官方 CLI 0.1.1 与技能 v0.1.7；不会自动改用旧 Key。")
    for name in list(env):
        if name.upper() == "LCZYAI_API_KEY":
            del env[name]  # Do not pass a legacy credential into the bridge process.
    try:
        version = subprocess.run(
            [str(cli / "node.exe"), str(cli / "lczyai.mjs"), "--version"],
            capture_output=True, text=True, encoding="utf-8", timeout=15,
            env=env, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        result = json.loads(version.stdout)
        valid = version.returncode == 0 and result.get("ok") is True and result["data"]["version"] == "0.1.1"
    except (OSError, ValueError, KeyError, subprocess.TimeoutExpired):
        valid = False
    if not valid:
        raise ValueError("CLI 启动或版本检查失败；请检查官方安装，不会自动改用旧 Key。")
    return [sys.executable, str(bridge), "--skill-root", str(skill), *remaining], env


def main(argv=None):
    args, env = command(sys.argv[1:] if argv is None else argv)
    # Preserve the child exit code. Never retry a production request here.
    return subprocess.call(args, env=env)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (ValueError, OSError) as exc:
        print(str(exc) if isinstance(exc, ValueError) else "无法启动客户端，请核对安装路径。", file=sys.stderr)
        sys.exit(1)
